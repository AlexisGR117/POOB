package test;
import domain.*;
import static org.junit.Assert.*;
import org.junit.Test;

public class DamasTest {
    @Test
    public void deberiaPoderCrearUnNuevoJuegoDeDamas() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	assertEquals("Nombre Norte", dapoos.jugadorNorte().nombre());
        	assertEquals("Negro", dapoos.jugadorNorte().color());
        	assertEquals(0, dapoos.jugadorNorte().movimientos());
        	assertEquals('n', dapoos.jugadorNorte().lado());
        	assertEquals(20, dapoos.jugadorNorte().numeroFichas());
        	assertEquals("Nombre Sur", dapoos.jugadorSur().nombre());
        	assertEquals("Blanco", dapoos.jugadorSur().color());
        	assertEquals(0, dapoos.jugadorSur().movimientos());
        	assertEquals('s', dapoos.jugadorSur().lado());
        	assertEquals(20, dapoos.jugadorSur().numeroFichas());    
        	int tamano = Tablero.TAMANOLADO;
        	assertEquals(10, tamano);    
    		for (int i = 0; i < tamano; i++) for (int j = 0; j < tamano; j++) {
    			if((i%2 == 0 && j%2 != 0) || (i%2 != 0 && j%2 == 0)) {
    				if (i < tamano/2 - 1 || i > tamano/2) {
	 					assertEquals(i, dapoos.tablero().casillas()[i][j].fila());
						assertEquals(j, dapoos.tablero().casillas()[i][j].columna());
						assertEquals(dapoos.tablero(), dapoos.tablero().casillas()[i][j].tablero());
						assertTrue(dapoos.tablero().casillas()[i][j].ficha() instanceof Peon);
	    				if (i < tamano/2 - 1) assertEquals(dapoos.jugadorNorte(), dapoos.tablero().casillas()[i][j].ficha().jugador());
	    				if (i > tamano/2) assertEquals(dapoos.jugadorSur(), dapoos.tablero().casillas()[i][j].ficha().jugador());
    				}
    			}
    		}
    		assertEquals(dapoos.jugadorSur(), dapoos.turno()); 
    		assertNull(dapoos.ganador());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    	
    }
    
    @Test
    public void deberiaLanzarUnaExcepcionSiElPrimerNombreTieneLongitudMayorA14() {
        try { 
        	new DAPOOS("Nombre Largo Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.LONG_NAME, e.getMessage());
        }  
    }   
    
    @Test
    public void deberiaLanzarUnaExcepcionSiElSegundoNombreTieneLongitudMayorA14() {
        try { 
        	new DAPOOS("Nombre Norte", "Nombre Largo Sur", "Negro", "Blanco", 0, "Normal", 0);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.LONG_NAME, e.getMessage());
        }  
    }   
    
    @Test
    public void deberiaLanzarUnaExcepcionSiElPrimerNombreTieneLongitudMenorA3() {
        try { 
        	new DAPOOS("No", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.SHORT_NAME, e.getMessage());
        }  
    }   
    
    @Test
    public void deberiaLanzarUnaExcepcionSiElSegundoNombreTieneLongitudMenorA3() {
        try { 
        	new DAPOOS("Nombre Norte", "Su", "Negro", "Blanco", 0, "Normal", 0);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.SHORT_NAME, e.getMessage());
        }  
    }   
    
    @Test
    public void deberiaLanzarUnaExcepcionSiLosDosJugadoresTienenElMismoNombre() {
        try { 
        	new DAPOOS("Nombre", "Nombre", "Negro", "Blanco", 0, "Normal", 0);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.SAME_NAMES, e.getMessage());
        }  
    }   
    
    @Test
    public void deberiaLanzarUnaExcepcionSiLosDosJugadoresTienenElMismoColor() {
        try { 
        	new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Negro", 0, "Normal", 0);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.SAME_COLORS, e.getMessage());
        }  
    }   
    
    @Test
    public void deberiaLanzarUnaExcepcionSiElPorcentajeEsMenorA0() {
        try { 
        	new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", -1, "Normal", 0);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.INVALID_PERCENTAGE, e.getMessage());
        }  
    }   
    
    @Test
    public void deberiaLanzarUnaExcepcionSiElPorcentajeEsMayorA100() {
        try { 
        	new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 101, "Normal", 0);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.INVALID_PERCENTAGE, e.getMessage());
        }  
    }   
    
    @Test
    public void deberiaLanzarUnaExcepcionSiLaDificultadDadaNoEstaEntreLasEstablecidad() {
        try { 
        	new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 30, "Rápido", 0);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.INVALID_DIFFICULTY, e.getMessage());
        }  
    }  
    
    @Test
    public void deberiaLanzarUnaExcepcionSiElTiempoDeTurnoEsMenorA0() {
        try { 
        	new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 50, "QuickTime", -1);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.INVALID_TIME_TURN, e.getMessage());
        }  
    }   
    
    @Test
    public void deberiaLanzarUnaExcepcionSiElTiempoDeTurnoEsMayorA100() {
        try { 
        	new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 50, "QuickTime", 101);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.INVALID_TIME_TURN, e.getMessage());
        }  
    }   
    
    @Test
    public void deberiaPoderMoverFichas() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	Ficha ficha = tablero.casillas()[6][1].ficha();
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(5, 0);
        	assertNull(tablero.casillas()[6][1].ficha());
            assertEquals(ficha, tablero.casillas()[5][0].ficha());
            assertEquals(1, dapoos.jugadorSur().movimientos());
        	Ficha ficha2 = tablero.casillas()[3][4].ficha();
        	tablero.seleccionar(ficha2);
        	tablero.moverSeleccion(4, 5);
        	assertNull(tablero.casillas()[3][4].ficha());
            assertEquals(ficha2, tablero.casillas()[4][5].ficha());
            assertEquals(1, dapoos.jugadorNorte().movimientos());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaCambiarDeTurnoAlMover() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	assertEquals(dapoos.jugadorSur(), dapoos.turno());
        	tablero.seleccionar(tablero.casillas()[6][1].ficha());
        	tablero.moverSeleccion(5, 0);
        	assertEquals(dapoos.jugadorNorte(), dapoos.turno());
        	tablero.seleccionar(tablero.casillas()[3][4].ficha());
        	tablero.moverSeleccion(4, 5);
        	assertEquals(dapoos.jugadorSur(), dapoos.turno());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaPoderConsultarElNombreDelugadorQueTieneElTurno() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	assertEquals("Nombre Sur", dapoos.turno().nombre());
        	tablero.seleccionar(tablero.casillas()[6][1].ficha());
        	tablero.moverSeleccion(5, 0);
        	assertEquals("Nombre Norte", dapoos.turno().nombre());
        	tablero.seleccionar(tablero.casillas()[3][4].ficha());
        	tablero.moverSeleccion(4, 5);
        	assertEquals("Nombre Sur", dapoos.turno().nombre());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaPoderConsultarElNombreDelJugadorSur() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	assertEquals("Nombre Sur", dapoos.jugadorSur().nombre());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaPoderConsultarElNombreDelJugadorNorte() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	assertEquals("Nombre Norte", dapoos.jugadorNorte().nombre());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaPoderConsultarElColorDelJugadorSur() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	assertEquals("Blanco", dapoos.jugadorSur().color());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaPoderConsultarElColorDelJugadorNorte() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	assertEquals("Negro", dapoos.jugadorNorte().color());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaPoderConsultarElNumeroDeFichasDelJugadorSur() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	assertEquals(20, dapoos.jugadorSur().numeroFichas());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaPoderConsultarElNumeroDeFichasDelJugadorNorte() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	assertEquals(20, dapoos.jugadorNorte().numeroFichas());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaPoderConsultarElNumeroDeMovimientosDelJugadorSur() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	assertEquals(0, dapoos.jugadorSur().movimientos());
          	tablero.seleccionar(tablero.casillas()[6][9].ficha());
        	tablero.moverSeleccion(5, 8);
        	assertEquals(1, dapoos.jugadorSur().movimientos());
        	tablero.seleccionar(tablero.casillas()[3][8].ficha());
        	tablero.moverSeleccion(4, 9);
        	tablero.seleccionar(tablero.casillas()[7][8].ficha());
        	tablero.moverSeleccion(6, 9);
        	tablero.seleccionar(tablero.casillas()[2][7].ficha());
        	tablero.moverSeleccion(3, 8);
        	assertEquals(2, dapoos.jugadorSur().movimientos());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaPoderConsultarElNumeroDeMovimientosDelJugadorNorte() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
           	Tablero tablero = dapoos.tablero();
           	assertEquals(0, dapoos.jugadorNorte().movimientos());
          	tablero.seleccionar(tablero.casillas()[6][9].ficha());
        	tablero.moverSeleccion(5, 8);
        	tablero.seleccionar(tablero.casillas()[3][8].ficha());
        	tablero.moverSeleccion(4, 9);
        	assertEquals(1, dapoos.jugadorNorte().movimientos());
        	tablero.seleccionar(tablero.casillas()[7][8].ficha());
        	tablero.moverSeleccion(6, 9);
        	tablero.seleccionar(tablero.casillas()[2][7].ficha());
        	tablero.moverSeleccion(3, 8);
        	assertEquals(2, dapoos.jugadorNorte().movimientos());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaEliminarseLaFichaDelJugadorSurSiEsCapturada() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
           	assertEquals(0, dapoos.jugadorNorte().movimientos());
           	Ficha ficha = tablero.casillas()[6][9].ficha();
          	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(5, 8);
        	tablero.seleccionar(tablero.casillas()[3][8].ficha());
        	tablero.moverSeleccion(4, 9);
        	tablero.seleccionar(tablero.casillas()[6][7].ficha());
        	tablero.moverSeleccion(5, 6);
        	tablero.seleccionar(tablero.casillas()[4][9].ficha());
        	tablero.moverSeleccion(6, 7);
        	assertFalse(dapoos.jugadorSur().fichas().contains(ficha));
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaEliminarseLaFichaDelJugadorNorteSiEsCapturada() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
           	assertEquals(0, dapoos.jugadorNorte().movimientos());
           	Ficha ficha = tablero.casillas()[3][0].ficha();
          	tablero.seleccionar(tablero.casillas()[6][1].ficha());
        	tablero.moverSeleccion(5, 2);
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(4, 1);
        	tablero.seleccionar(tablero.casillas()[5][2].ficha());
        	tablero.moverSeleccion(3, 0);
        	assertFalse(dapoos.jugadorNorte().fichas().contains(ficha));
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaDismisnuirElNumeroDeFichasDelJugadorSurSiLeCapturanAlguna() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
           	assertEquals(0, dapoos.jugadorNorte().movimientos());
           	Ficha ficha = tablero.casillas()[6][9].ficha();
          	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(5, 8);
        	tablero.seleccionar(tablero.casillas()[3][8].ficha());
        	tablero.moverSeleccion(4, 9);
        	tablero.seleccionar(tablero.casillas()[6][7].ficha());
        	tablero.moverSeleccion(5, 6);
        	tablero.seleccionar(tablero.casillas()[4][9].ficha());
        	tablero.moverSeleccion(6, 7);
        	assertEquals(19, dapoos.jugadorSur().numeroFichas());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaDismisnuirElNumeroDeFichasDelJugadorNorteSiLeCapturanAlguna() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
           	assertEquals(0, dapoos.jugadorNorte().movimientos());
           	Ficha ficha = tablero.casillas()[3][0].ficha();
          	tablero.seleccionar(tablero.casillas()[6][1].ficha());
        	tablero.moverSeleccion(5, 2);
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(4, 1);
        	tablero.seleccionar(tablero.casillas()[5][2].ficha());
        	tablero.moverSeleccion(3, 0);
        	assertEquals(19, dapoos.jugadorNorte().numeroFichas());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaLanzarUnaExcepcionSiElJugadorQueNoTieneElTurnoIntentaJugar() {
        try { 
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.seleccionar(tablero.casillas()[3][0].ficha());
        	tablero.moverSeleccion(4, 1);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.INVALID_PLAYER, e.getMessage());
        } 
    }
    
    @Test
    public void deberiaPoderCapturarFichas() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	Ficha ficha = tablero.casillas()[6][3].ficha();
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(5, 4);       	
        	Ficha ficha2 = tablero.casillas()[3][2].ficha();
        	tablero.seleccionar(ficha2);
        	tablero.moverSeleccion(4, 3);
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(3, 2);
        	assertNull(tablero.casillas()[4][3].ficha());
        	assertEquals(ficha, tablero.casillas()[3][2].ficha());
        	assertEquals(19, dapoos.jugadorNorte().numeroFichas());
        	assertFalse(dapoos.jugadorNorte().fichas().contains(ficha2));
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }   
    
    @Test
    public void deberiaEliminarseUnaFichaSiElJugadorNoCapturaTeniendoLaPosibilidad() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	Ficha ficha = tablero.casillas()[6][3].ficha();
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(5, 4);
        	tablero.seleccionar(tablero.casillas()[3][2].ficha());
        	tablero.moverSeleccion(4, 3);
        	tablero.seleccionar(tablero.casillas()[6][1].ficha());
        	tablero.moverSeleccion(5, 0);
        	assertNull(tablero.casillas()[4][5].ficha());
        	assertNull(tablero.casillas()[5][4].ficha());
        	assertEquals(19, dapoos.jugadorSur().numeroFichas());
        	assertFalse(dapoos.jugadorSur().fichas().contains(ficha));
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }   
    
    @Test
    public void deberiaLanzarUnaExcepcionSiEnLaPosicionALaQueSeQuiereMoverHayOtraFicha() {
        try { 
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.seleccionar(tablero.casillas()[7][0].ficha());
        	tablero.moverSeleccion(6, 1);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.NOT_EMPTY, e.getMessage());
        } 
    }
    
    @Test
    public void deberiaLanzarUnaExcepcionSiALaColumnaALaQueSeQuiereMoverEstaFueraDelTablero() {
        try { 
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.seleccionar(tablero.casillas()[6][9].ficha());
        	tablero.moverSeleccion(5, 10);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.OFF_THE_BOARD, e.getMessage());
        } 
    }
    
    @Test
    public void deberiaLanzarUnaExcepcionSiALaFilaALaQueSeQuiereMoverEstaFueraDelTablero() {
        try { 
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.seleccionar(tablero.casillas()[6][9].ficha());
        	tablero.moverSeleccion(5, 8);
        	tablero.seleccionar(tablero.casillas()[3][8].ficha());
        	tablero.moverSeleccion(4, 9);
        	tablero.seleccionar(tablero.casillas()[7][8].ficha());
        	tablero.moverSeleccion(6, 9);
        	tablero.seleccionar(tablero.casillas()[2][7].ficha());
        	tablero.moverSeleccion(3, 8);
        	tablero.seleccionar(tablero.casillas()[8][9].ficha());
        	tablero.moverSeleccion(7, 8);
        	tablero.seleccionar(tablero.casillas()[1][8].ficha());
        	tablero.moverSeleccion(2, 7);
        	tablero.seleccionar(tablero.casillas()[6][7].ficha());
        	tablero.moverSeleccion(5, 6);
        	tablero.seleccionar(tablero.casillas()[4][9].ficha());
        	tablero.moverSeleccion(6, 7);
        	tablero.seleccionar(tablero.casillas()[6][7].ficha());
        	tablero.moverSeleccion(8, 9);
        	tablero.seleccionar(tablero.casillas()[8][7].ficha());
        	tablero.moverSeleccion(7, 8);
        	tablero.seleccionar(tablero.casillas()[3][8].ficha());
        	tablero.moverSeleccion(4, 9);
        	tablero.seleccionar(tablero.casillas()[9][8].ficha());
        	tablero.moverSeleccion(8, 7);
        	tablero.seleccionar(tablero.casillas()[8][9].ficha());
        	tablero.moverSeleccion(9, 8);
        	tablero.seleccionar(tablero.casillas()[7][8].ficha());
        	tablero.moverSeleccion(6, 7);
        	tablero.seleccionar(tablero.casillas()[9][8].ficha());
        	tablero.moverSeleccion(10, 9);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.OFF_THE_BOARD, e.getMessage());
        } 
    }
    
    @Test
    public void deberiaLanzarUnaExcepcionSiElJugadorNorteIntentaMoverUnPeonHaciaElNorte() {
        try { 
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.seleccionar(tablero.casillas()[6][5].ficha());
        	tablero.moverSeleccion(5, 6);
        	tablero.seleccionar(tablero.casillas()[3][4].ficha());
        	tablero.moverSeleccion(4, 3);
        	tablero.seleccionar(tablero.casillas()[6][7].ficha());
        	tablero.moverSeleccion(5, 8);
        	tablero.seleccionar(tablero.casillas()[4][3].ficha());
        	tablero.moverSeleccion(3, 4);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.INVALID_MOVEMENT, e.getMessage());
        } 
    }
 
    @Test
    public void deberiaLanzarUnaExcepcionSiElJugadorSurIntentaMoverUnPeonHaciaElSur() {
        try { 
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.seleccionar(tablero.casillas()[6][5].ficha());
        	tablero.moverSeleccion(5, 6);
        	tablero.seleccionar(tablero.casillas()[3][4].ficha());
        	tablero.moverSeleccion(4, 3);
        	tablero.seleccionar(tablero.casillas()[5][6].ficha());
        	tablero.moverSeleccion(6, 5);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.INVALID_MOVEMENT, e.getMessage());
        } 
    }
    
    @Test
    public void deberiaLanzarUnaExcepcionSiSeIntentaMoverUnaFichaAUnaCasillaBlanca() {
        try { 
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.seleccionar(tablero.casillas()[6][5].ficha());
        	tablero.moverSeleccion(5, 5);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.WHITE_SQUARE, e.getMessage());
        } 
    }
    
    @Test
    public void deberiaLanzarUnaExcepcionSiSeIntentaMoverUnPeonMasDeUnaCasillaSinCapturar() {
        try { 
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.seleccionar(tablero.casillas()[6][5].ficha());
        	tablero.moverSeleccion(4, 7);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.INVALID_MOVEMENT, e.getMessage());
        } 
    }
    
    @Test
    public void deberiaEliminarseLaFichaSiElJugadorNoCapturaTeniendoLaPosibilidadDeVolverACapturarConLaMismaFicha() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.seleccionar(tablero.casillas()[6][9].ficha());
        	tablero.moverSeleccion(5, 8);
        	Ficha ficha = tablero.casillas()[3][8].ficha();
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(4, 9);
        	tablero.seleccionar(tablero.casillas()[7][8].ficha());
        	tablero.moverSeleccion(6, 9);
        	tablero.seleccionar(tablero.casillas()[2][7].ficha());
        	tablero.moverSeleccion(3, 8);
        	tablero.seleccionar(tablero.casillas()[8][9].ficha());
        	tablero.moverSeleccion(7, 8);
        	tablero.seleccionar(tablero.casillas()[1][8].ficha());
        	tablero.moverSeleccion(2, 7);
        	tablero.seleccionar(tablero.casillas()[6][5].ficha());
        	tablero.moverSeleccion(5, 4);        	
        	tablero.seleccionar(tablero.casillas()[0][9].ficha());
        	tablero.moverSeleccion(1, 8);        	
        	tablero.seleccionar(tablero.casillas()[7][6].ficha());
        	tablero.moverSeleccion(6, 5);        	
        	tablero.seleccionar(tablero.casillas()[3][0].ficha());
        	tablero.moverSeleccion(4, 1);        	
        	tablero.seleccionar(tablero.casillas()[6][7].ficha());
        	tablero.moverSeleccion(5, 6);        	
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(6, 7);        	
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(7, 6);        	
        	assertNull(tablero.casillas()[4][9].ficha());
        	assertNull(tablero.casillas()[5][8].ficha());
        	assertNull(tablero.casillas()[6][7].ficha());
        	assertNull(tablero.casillas()[7][6].ficha());
        	assertFalse(dapoos.jugadorNorte().fichas().contains(ficha));
        	assertEquals(19, dapoos.jugadorNorte().numeroFichas());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaPoderHacerMasDeUnMovimientoSiPuedoVolverACapturar() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.seleccionar(tablero.casillas()[6][9].ficha());
        	tablero.moverSeleccion(5, 8);
        	Ficha ficha = tablero.casillas()[3][8].ficha();
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(4, 9);
        	tablero.seleccionar(tablero.casillas()[7][8].ficha());
        	tablero.moverSeleccion(6, 9);
        	tablero.seleccionar(tablero.casillas()[2][7].ficha());
        	tablero.moverSeleccion(3, 8);
        	tablero.seleccionar(tablero.casillas()[8][9].ficha());
        	tablero.moverSeleccion(7, 8);
        	tablero.seleccionar(tablero.casillas()[1][8].ficha());
        	tablero.moverSeleccion(2, 7);
        	tablero.seleccionar(tablero.casillas()[6][7].ficha());
        	tablero.moverSeleccion(5, 6);
        	assertEquals(dapoos.jugadorNorte(), dapoos.turno());
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(6, 7);
        	assertEquals(dapoos.jugadorNorte(), dapoos.turno());
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(8, 9);
        	assertNull(tablero.casillas()[5][8].ficha());
        	assertNull(tablero.casillas()[7][8].ficha());
        	assertEquals(ficha, tablero.casillas()[8][9].ficha());
        	assertEquals(18, dapoos.jugadorSur().numeroFichas());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberiaLanzarUnaExcepcionSiEnUnMismoTurnoIntentaMoverMasDeUnaFicha() {
        try { 
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.seleccionar(tablero.casillas()[6][9].ficha());
        	tablero.moverSeleccion(5, 8);
        	tablero.seleccionar(tablero.casillas()[3][8].ficha());
        	tablero.moverSeleccion(4, 9);
        	tablero.seleccionar(tablero.casillas()[7][8].ficha());
        	tablero.moverSeleccion(6, 9);
        	tablero.seleccionar(tablero.casillas()[2][7].ficha());
        	tablero.moverSeleccion(3, 8);
        	tablero.seleccionar(tablero.casillas()[8][9].ficha());
        	tablero.moverSeleccion(7, 8);
        	tablero.seleccionar(tablero.casillas()[1][8].ficha());
        	tablero.moverSeleccion(2, 7);
        	tablero.seleccionar(tablero.casillas()[6][7].ficha());
        	tablero.moverSeleccion(5, 6);
        	tablero.seleccionar(tablero.casillas()[4][9].ficha());
        	tablero.moverSeleccion(6, 7);
        	tablero.seleccionar(tablero.casillas()[3][0].ficha());
        	tablero.moverSeleccion(4, 1);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.ONE_TOKEN_PER_TURN, e.getMessage());
        } 
    }
    
    @Test
    public void deberiaPoderCrearUnNuevoJuegoDeDapoosConCasillasEspeciales() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 100, "Normal", 0);
        	int tamano = Tablero.TAMANOLADO;
    		for (int i = tamano/2 - 1; i <= tamano/2; i++) for (int j = 0; j < tamano; j++) {
    			if((i%2 == 0 && j%2 != 0) || (i%2 != 0 && j%2 == 0)) {
    				Casilla casilla = dapoos.tablero().casillas()[i][j];
    				assertTrue(casilla instanceof Mine || casilla instanceof Jail || casilla instanceof Teleport);
    			}
    		}
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberianCrearseLAsCasillasEspecialesDeAcuerdoAlPorcentajeDado() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 60, "Normal", 0);
        	int tamano = Tablero.TAMANOLADO;
        	int c = 0;
    		for (int i = tamano/2 - 1; i <= tamano/2; i++) for (int j = 0; j < tamano; j++) {
    			if((i%2 == 0 && j%2 != 0) || (i%2 != 0 && j%2 == 0)) {
    				Casilla casilla = dapoos.tablero().casillas()[i][j];
    				if (casilla instanceof Mine || casilla instanceof Jail || casilla instanceof Teleport) c ++;
    			}
    		}
    		assertEquals((int)((double)((double)60/(double)100)*(double)tamano), c);
        	DAPOOS damas2 = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 94, "Normal", 0);
        	c = 0;
    		for (int i = tamano/2 - 1; i <= tamano/2; i++) for (int j = 0; j < tamano; j++) {
    			if((i%2 == 0 && j%2 != 0) || (i%2 != 0 && j%2 == 0)) {
    				Casilla casilla = damas2.tablero().casillas()[i][j];
    				if (casilla instanceof Mine || casilla instanceof Jail || casilla instanceof Teleport) c ++;
    			}
    		}
    		assertEquals((int)((double)((double)94/(double)100)*(double)tamano), c);
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberianPoderTenerFichasDamas() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Casilla casilla = dapoos.tablero().casillas()[6][9];
        	casilla.colocarFicha(new Dama(dapoos.jugadorSur()));
        	assertTrue(casilla.ficha() instanceof Dama);
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberianPoderMoverseMasDeUnaCasillasUnaDama() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	Casilla casilla = tablero.casillas()[6][9];
        	casilla.ficha().capturar();
        	casilla.colocarFicha(new Dama(dapoos.jugadorSur()));
        	Ficha ficha = casilla.ficha();
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(4, 7);
        	assertNull(tablero.casillas()[6][9].ficha());
        	assertEquals(ficha, tablero.casillas()[4][7].ficha());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberianPoderDevolvermeConUnaDama() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	Casilla casilla = tablero.casillas()[6][9];
        	casilla.ficha().capturar();
        	casilla.colocarFicha(new Dama(dapoos.jugadorSur()));
        	Ficha ficha = casilla.ficha();
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(5, 8);
        	tablero.seleccionar(tablero.casillas()[3][8].ficha());
        	tablero.moverSeleccion(4, 9);
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(6, 9);
        	assertNull(tablero.casillas()[5][8].ficha());
        	assertEquals(ficha, tablero.casillas()[6][9].ficha());
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberianPoderCapturarAMasDe2CasillasConUnaDama() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	Casilla casilla = tablero.casillas()[6][9];
        	casilla.ficha().capturar();
        	casilla.colocarFicha(new Dama(dapoos.jugadorSur()));
        	Ficha ficha = casilla.ficha();
        	tablero.seleccionar(tablero.casillas()[6][1].ficha());
        	tablero.moverSeleccion(5, 0);
        	Ficha ficha2 = tablero.casillas()[3][6].ficha();
        	tablero.seleccionar(ficha2);
        	tablero.moverSeleccion(4, 7);
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(3, 6);
        	assertNull(tablero.casillas()[6][9].ficha());
        	assertNull(tablero.casillas()[4][7].ficha());
        	assertEquals(ficha, tablero.casillas()[3][6].ficha());
        	assertEquals(19, dapoos.jugadorNorte().numeroFichas());
        	assertFalse(dapoos.jugadorNorte().fichas().contains(ficha2));
        } catch (DAPOOSException e){
            fail("Threw a exception"+e.getMessage());
        }
    }
    
    @Test
    public void deberianPoderTenerCasillasJail() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.casillas()[5][8] = new Jail(tablero, 5, 8);
        	assertTrue(tablero.casillas()[5][8] instanceof Jail);
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberianLanzarUnaExcepcionSiSeIntentaMoverUnaFichaQueEstaEnUnaCasillaJailDespuesDeUnTurno() {
        try { 
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.casillas()[5][8] = new Jail(tablero, 5, 8);
        	tablero.seleccionar(tablero.casillas()[6][9].ficha());
        	tablero.moverSeleccion(5, 8);
        	tablero.seleccionar(tablero.casillas()[3][8].ficha());
        	tablero.moverSeleccion(4, 9);
        	tablero.seleccionar(tablero.casillas()[5][8].ficha());
        	tablero.moverSeleccion(4, 7);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.INVALID_MOVEMENT, e.getMessage());
        } 
    }
    
    @Test
    public void deberianLanzarUnaExcepcionSiSeIntentaMoverUnaFichaQueEstaEnUnaCasillaJailDespuesDeDosTurnos() {
        try { 
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.casillas()[5][8] = new Jail(tablero, 5, 8);
        	tablero.seleccionar(tablero.casillas()[6][9].ficha());
        	tablero.moverSeleccion(5, 8);
        	tablero.seleccionar(tablero.casillas()[3][8].ficha());
        	tablero.moverSeleccion(4, 9);
        	tablero.seleccionar(tablero.casillas()[6][1].ficha());
        	tablero.moverSeleccion(5, 0);
        	tablero.seleccionar(tablero.casillas()[3][0].ficha());
        	tablero.moverSeleccion(4, 1);
        	tablero.seleccionar(tablero.casillas()[5][8].ficha());
        	tablero.moverSeleccion(4, 7);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.INVALID_MOVEMENT, e.getMessage());
        } 
    }
    
    @Test
    public void deberianPoderMoverUnaFichaQueEstaEnUnaCasilaJailDespuesDeDosTurnos() {
        try { 
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.casillas()[5][8] = new Jail(tablero, 5, 8);
        	Ficha ficha = tablero.casillas()[6][9].ficha();
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(5, 8);
        	tablero.seleccionar(tablero.casillas()[3][8].ficha());
        	tablero.moverSeleccion(4, 9);
        	tablero.seleccionar(tablero.casillas()[6][1].ficha());
        	tablero.moverSeleccion(5, 0);
        	tablero.seleccionar(tablero.casillas()[3][0].ficha());
        	tablero.moverSeleccion(4, 1);
        	tablero.seleccionar(tablero.casillas()[6][3].ficha());
        	tablero.moverSeleccion(5, 4);
        	tablero.seleccionar(tablero.casillas()[3][4].ficha());
        	tablero.moverSeleccion(4, 5);
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(4, 7);
        	assertNull(tablero.casillas()[5][8].ficha());
        	assertEquals(ficha, tablero.casillas()[4][7].ficha());
        } catch (DAPOOSException e) {
        	 fail("Threw a exception");
        } 
    }
    
    @Test
    public void noDeberiaEliminarseLaFichaEncarceladaSiElJugadorTienePosibilidadDeCapturarConEstaYNoCaptura() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.casillas()[5][4] = new Jail(tablero, 5, 4);
        	Ficha ficha = tablero.casillas()[6][3].ficha();
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(5, 4);
        	tablero.seleccionar(tablero.casillas()[3][2].ficha());
        	tablero.moverSeleccion(4, 3);
        	tablero.seleccionar(tablero.casillas()[6][1].ficha());
        	tablero.moverSeleccion(5, 0);
        	assertEquals(ficha, tablero.casillas()[5][4].ficha());
        	assertEquals(20, dapoos.jugadorSur().numeroFichas());
        	assertTrue(dapoos.jugadorSur().fichas().contains(ficha));
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberianPoderTenerCasillasTeleport() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.casillas()[5][8] = new Teleport(tablero, 5, 8);
        	assertTrue(tablero.casillas()[5][8] instanceof Teleport);
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberianTeletransportarseAUnLugarAleatorioUnaFichaQuePisaUnaCasillaTeleport() {
        try { 
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.casillas()[5][8] = new Teleport(tablero, 5, 8);
        	Ficha ficha = tablero.casillas()[6][9].ficha();
        	tablero.seleccionar(ficha);
        	tablero.moverSeleccion(5, 8);
        	boolean enCasilla = false;
        	for (Casilla[] f: tablero.casillas()) for (Casilla c:f) {
        		if (c != null && c.ficha() == ficha) enCasilla = true;
        	}
        	assertTrue(enCasilla);
        	assertFalse(tablero.casillas()[5][8].ficha() == ficha);
        } catch (DAPOOSException e) {
        	 fail("Threw a exception");
        } 
    }
    
    @Test
    public void deberianPoderTenerCasillasMine() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.casillas()[5][8] = new Mine(tablero, 5, 8);
        	assertTrue(tablero.casillas()[5][8] instanceof Mine);
        } catch (DAPOOSException e){
            fail("Threw a exception");
        }
    }
    
    @Test
    public void deberianEliminarseTodasLasFichasQueEstenEnElEspacio3x3DeLaBombaAlSerPisadaPorUnaFicha() {
        try { 
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.casillas()[5][8] = new Mine(tablero, 5, 8);
        	tablero.seleccionar(tablero.casillas()[6][1].ficha());
        	tablero.moverSeleccion(5, 0);
        	Ficha ficha1 = tablero.casillas()[3][8].ficha();
        	tablero.seleccionar(ficha1);
        	tablero.moverSeleccion(4, 9);
        	tablero.seleccionar(tablero.casillas()[6][3].ficha());
        	tablero.moverSeleccion(5, 2);
        	Ficha ficha2 = tablero.casillas()[3][6].ficha();
        	tablero.seleccionar(ficha2);
        	tablero.moverSeleccion(4, 7);
        	Ficha ficha3 = tablero.casillas()[6][9].ficha();
        	tablero.seleccionar(ficha3);
        	tablero.moverSeleccion(5, 8);
        	Ficha ficha4 = tablero.casillas()[6][7].ficha();
        	assertNull(tablero.casillas()[4][7].ficha());
        	assertNull(tablero.casillas()[4][9].ficha());
        	assertNull(tablero.casillas()[5][8].ficha());
        	assertNull(tablero.casillas()[6][7].ficha());
        	assertNull(tablero.casillas()[6][9].ficha());
        	assertEquals(18, dapoos.jugadorNorte().numeroFichas());
        	assertEquals(18, dapoos.jugadorSur().numeroFichas());
        	assertFalse(dapoos.jugadorNorte().fichas().contains(ficha1));
        	assertFalse(dapoos.jugadorNorte().fichas().contains(ficha2));
        	assertFalse(dapoos.jugadorSur().fichas().contains(ficha3));
        	assertFalse(dapoos.jugadorSur().fichas().contains(ficha4));
        } catch (DAPOOSException e) {
        	 fail("Threw a exception");
        } 
    }
    
    @Test
    public void deberiaLanzarUnaExcepcionSiNoSeHaSeleccionadoUnaFichaYSeIntentaMover() {
        try { 
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "Normal", 0);
        	Tablero tablero = dapoos.tablero();
        	tablero.moverSeleccion(5, 6);
            fail("Did not throw exception");
        } catch (DAPOOSException e) {
            assertEquals(DAPOOSException.NOT_SELECTED, e.getMessage());
        } 
    }
    
    /*
    @Test
    public void deberiaCambiarDeTurnoDespuesDe20SegundosEnQuickTime() {
        try {
        	DAPOOS dapoos = new DAPOOS("Nombre Norte", "Nombre Sur", "Negro", "Blanco", 0, "QuickTime", 1);
        	assertEquals(dapoos.jugadorSur(), dapoos.turno());
        	Thread.sleep(4*1000);
        	assertEquals(dapoos.jugadorNorte(), dapoos.turno());
        	Thread.sleep(5*1000);
        	assertEquals(dapoos.jugadorSur(), dapoos.turno());
        } catch (Exception e){
            fail("Threw a exception");
        }
    }
    */
     
}
