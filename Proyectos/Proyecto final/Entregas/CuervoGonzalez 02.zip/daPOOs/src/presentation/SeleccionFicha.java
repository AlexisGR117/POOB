package presentation;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.LineBorder;

public class SeleccionFicha extends JDialog{
    private JButton beginner, apprentice;
    /**
     * Constructor for objects of class WindoSetColors.
     */
    public SeleccionFicha() {
        //super(gui, Dialog. ModalityType.DOCUMENT_MODAL);
        //this.gui = gui;
        prepararElementos();
        prepararAcciones();
        setVisible(true);
    } 
    
    /*
     * preparar the Elementos with which the user interacts.
     */
    private void prepararElementos() {   
        setSize(410, 220);
        setTitle("Selección de máquina");
        setLocationRelativeTo(null);
        setLayout(new GridLayout(1,1));
        Fondo fondo = new Fondo("FondoCuadrados");
        fondo.setLayout(null);
        Font font = new Font("Perpetua", Font.BOLD, 35);
        Cursor cursor = new Cursor(Cursor.HAND_CURSOR);
        LineBorder border = new LineBorder(Color.black, 2);
        JLabel label = new JLabel("Nivel de la máquina");
        label.setBounds(50, 20, 400, 30);
        label.setFont(font);
        font = new Font("Perpetua", 0, 30);
        beginner = new JButton("Principiante");
        beginner.setBounds(50, 60, 300, 45);
        beginner.setCursor(cursor);
        beginner.setBackground(Color.white);
        beginner.setBorder(border);
        beginner.setFont(font);
        apprentice = new JButton("Aprendiz");
        apprentice.setBounds(50, 120, 300, 45);
        apprentice.setCursor(cursor);
        apprentice.setBackground(Color.white);
        apprentice.setBorder(border);
        apprentice.setFont(font);
        fondo.add(label);
        fondo.add(beginner);
        fondo.add(apprentice);
        add(fondo);
    } 
    
    /*
     * preparar accions of TantFant.
     */
    private void prepararAcciones(){   
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        addWindowListener(new WindowAdapter(){
            @Override
            public void windowClosing(WindowEvent e){
                accionExit();
            }
        });
    } 
    
    /*
     * salir colores configuration.
     */
    private void accionExit(){   
        int respuesta = JOptionPane.showConfirmDialog(null, "¿Seguro que quieres salir de la selección de máquina?", "Salir seleccion máquina", JOptionPane.OK_CANCEL_OPTION);
        if (respuesta == JOptionPane.OK_OPTION){
            setVisible(false);
            dispose();
        }
    }
	 /**
	 * Main method of TantFant.
	 */
	public static void main(String[] args) {
	    SeleccionFicha gui = new SeleccionFicha();
	    gui.setVisible(true);
	} 
}