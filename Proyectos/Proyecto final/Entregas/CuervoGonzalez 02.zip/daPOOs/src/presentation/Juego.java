package presentation;

import domain.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.*;
import java.util.Timer;

public class Juego extends JFrame{
    private JMenuItem nuevo, abrir, guardar, salir;
    private JPanel tableroJuego, informacion, jugadorUno, jugadorDos;
    private JLabel colorUno, movimientosUno, fichasUno, capturasUno, damasUno;  
    private JLabel colorDos, movimientosDos, fichasDos, capturasDos, damasDos, turno, labelTimer;    
    private PanelCasilla[][] tablero;
    private Fondo fondo;
	private DAPOOS dapoos;
	private DAPOOSGUI gui;
	private String nombreUno, nombreDos, colorNorte, colorSur, visualizacion, dificultad;
	private int tiempo, porcentaje;
	private Timer timer, timerRelampago;
	
	public Juego(String nombreUno,String nombreDos,String colorNorte,String colorSur,String tipoMaquina,int porcentaje,
					String visualizacion,int tiempo,String dificultad, DAPOOSGUI gui) throws DAPOOSException{
		dapoos = new DAPOOS(nombreUno, nombreDos, colorNorte, colorSur, porcentaje, dificultad, tiempo);
        this.gui = gui;
        this.nombreUno = nombreUno;
        this.nombreDos = nombreDos;
		this.dificultad = dificultad;
		this.colorNorte = colorNorte;
		this.colorSur = colorSur;
		this.porcentaje = porcentaje;
		this.visualizacion = visualizacion;
		this.tiempo = tiempo;
		prepararElementos();
        prepararAcciones();
        setVisible(true);
	}
	/*
     * preparar the Elementos with which the user interacts.
     */
    private void prepararElementos() {   
    	if (dificultad.equals("QuickTime")) setSize(1045, 680);
    	else  setSize(1045, 665);
        setLayout(new GridLayout(1, 1));
        setLocationRelativeTo(null);
        setResizable(false);
        fondo = new Fondo("FondoBlanco");
        add(fondo);
        fondo.setVisible(true);
        fondo.setLayout(new BorderLayout());  
        prepararElementosMenu();
        prepararElementosTablero();
        prepararElementosjugadorUno();
        prepararElementosJugadorDos();
        prepararElementosInformacion();        
    } 
    /*
     * preparar the menu Elementos.
     */
    private void prepararElementosMenu() {   
        JMenuBar barra = new JMenuBar();
        JMenu menu = new JMenu("Menú"), setting = new JMenu("Configuración");
        nuevo = new JMenuItem("Nuevo");
        abrir = new JMenuItem("Abrir");
        guardar = new JMenuItem("Salvar");
        salir = new JMenuItem("Salir");
        barra.add(menu);
        barra.add(setting);
        menu.add(nuevo);
        menu.add(new JSeparator());
        menu.add(abrir);
        menu.add(guardar);
        menu.add(new JSeparator());
        menu.add(salir);
        setJMenuBar(barra);
    } 
    
    /*
     * preparar the tablero Elementos.
     */
    private void prepararElementosTablero() {  
        int tamano = Tablero.TAMANOLADO;
        JPanel panelC = new JPanel();
        panelC.setLayout(null);
        panelC.setOpaque(false);
        tableroJuego = new JPanel();
        tableroJuego.setBackground(Color.white);
        tableroJuego.setBorder(new LineBorder(Color.black, 3)); 
        tablero = new PanelCasilla[tamano][tamano];
        tableroJuego.setLayout(null);
        tableroJuego.setBounds(0, 0, 550, 550);
        JPanel casillas = new JPanel(), casillas2 = new JPanel();
        casillas.setOpaque(false);
        casillas2.setOpaque(false);
        casillas.setLayout(null);
        casillas.setBounds(20, 20, 510, 510);
        casillas.setBorder(new LineBorder(Color.black, 3));   
        casillas2.setLayout(new GridLayout(tamano, tamano));
        casillas2.setBounds(5, 5, 500, 500);
        casillas2.setBorder(new LineBorder(Color.black, 2));   
        tableroJuego.add(casillas);
        casillas.add(casillas2);
        for (int i = 0; i < tamano; i++) {
        	char l = (char)(i+65);
        	JLabel fila = new JLabel((tamano-i)+"", SwingConstants.CENTER), columna = new JLabel(l+"");
            fila.setBounds(5, 25+(500/(tamano*2))+(500/tamano)*i-i, 15, 15);
            columna.setBounds(25+(500/(tamano*2))+(500/tamano)*i-i, 8, 10, 10);
            tableroJuego.add(fila);
            tableroJuego.add(columna);
        	JLabel fila2 = new JLabel((tamano-i)+"", SwingConstants.CENTER), columna2 = new JLabel(l+"");
            fila2.setBounds(530, 25+(500/(tamano*2))+(500/tamano)*i-i, 15, 15);
            columna2.setBounds(25+(500/(tamano*2))+(500/tamano)*i-i, 535, 10, 10);
            tableroJuego.add(fila2);
            tableroJuego.add(columna2);
            for (int j = 0; j < tamano; j++) {
            	PanelCasilla casilla;
                if((i%2 == 0 && j%2 != 0) || (i%2 != 0 && j%2 == 0)) {
                	JButton boton = new JButton();
                    boton.setOpaque(false);
                    boton.setBorderPainted(false);
                    boton.setBackground(Tablero.COLORDOS);
                    boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
                    casilla = new PanelCasilla(i, j, this, boton);
                    casilla.add(boton);
                    casilla.setLayout(new GridLayout(1, 1));
                	casilla.setBackground(Tablero.COLORDOS);
                } else {
                	casilla = new PanelCasilla(i, j, this, null);
                	casilla.setBackground(Tablero.COLORUNO);
                }                  
                casillas2.add(casilla);
                tablero[i][j] = casilla;
            }
        }
    	if (visualizacion.equals("Relampago")) timerRelampago = new Timer();
    	panelC.add(tableroJuego);
        fondo.add(panelC, BorderLayout.CENTER);
    }  
    
    /*
     * preparar the tablero Elementos.
     */
    private void prepararElementosjugadorUno() {  
    	JPanel panelW = new JPanel();
        panelW.setOpaque(false);
    	panelW.setLayout(new GridLayout(3, 1));
    	JPanel uno = new JPanel();
    	uno.setOpaque(false);
    	panelW.add(uno);
        jugadorUno = new JPanel();
        jugadorUno.setOpaque(false);
        jugadorUno.setBorder(new CompoundBorder(new EmptyBorder(5, 5, 5, 5), new TitledBorder(new LineBorder(Color.black), "Jugador Norte")));
        jugadorUno.setLayout(new GridLayout(6, 2));
        jugadorUno.add(new JLabel("Nombre:"));
        JLabel nombreUno = new JLabel(dapoos.jugadorNorte().nombre(), SwingConstants.CENTER);
        nombreUno.setBounds(0, 0, 60, 20);
        jugadorUno.add(nombreUno);
        jugadorUno.add(new JLabel("Color:"));
        colorUno = new JLabel(dapoos.jugadorNorte().color(), SwingConstants.CENTER);
        jugadorUno.add(colorUno);
        jugadorUno.add(new JLabel("Movimientos:"));
        movimientosUno = new JLabel(dapoos.jugadorNorte().movimientos()+"", SwingConstants.CENTER);
        jugadorUno.add(movimientosUno);
        jugadorUno.add(new JLabel("Fichas:"));
        fichasUno = new JLabel(dapoos.jugadorNorte().numeroFichas()+"", SwingConstants.CENTER);
        jugadorUno.add(fichasUno);
        jugadorUno.add(new JLabel("Fichas capturadas:"));
        capturasUno = new JLabel(20-dapoos.jugadorSur().numeroFichas()+"", SwingConstants.CENTER);
        jugadorUno.add(capturasUno);
        jugadorUno.add(new JLabel("DAPOOS:"));
        damasUno = new JLabel(dapoos.jugadorNorte().numeroDamas()+"", SwingConstants.CENTER);
        jugadorUno.add(damasUno);
        panelW.add(jugadorUno);
        fondo.add(panelW, BorderLayout.WEST);
    }   
    
    /*
     * preparar the tablero Elementos.
     */
    private void prepararElementosJugadorDos() {  
    	JPanel panelE = new JPanel();
        panelE.setBackground(Color.white);
        panelE.setOpaque(false);
    	panelE.setLayout(new GridLayout(3, 1));
    	JPanel uno = new JPanel();
    	uno.setOpaque(false);
    	panelE.add(uno);
        jugadorDos = new JPanel();
        jugadorDos.setOpaque(false);
        jugadorDos.setBorder(new CompoundBorder(new EmptyBorder(5, 5, 5, 5), new TitledBorder(new LineBorder(Color.black), "Jugador Sur")));
        jugadorDos.setLayout(new GridLayout(6, 2));
        jugadorDos.add(new JLabel("Nombre:"));
        jugadorDos.add(new JLabel(dapoos.jugadorSur().nombre(), SwingConstants.CENTER));
        jugadorDos.add(new JLabel("Color:"));
        colorDos = new JLabel(dapoos.jugadorSur().color(), SwingConstants.CENTER);
        jugadorDos.add(colorDos);
        jugadorDos.add(new JLabel("Movimientos:"));
        movimientosDos = new JLabel(dapoos.jugadorSur().movimientos()+"", SwingConstants.CENTER);
        jugadorDos.add(movimientosDos);
        jugadorDos.add(new JLabel("Fichas:"));
        fichasDos = new JLabel(dapoos.jugadorSur().numeroFichas()+"", SwingConstants.CENTER);
        jugadorDos.add(fichasDos);
        jugadorDos.add(new JLabel("Fichas capturadas:"));
        capturasDos = new JLabel(20-dapoos.jugadorNorte().numeroFichas()+"", SwingConstants.CENTER);
        jugadorDos.add(capturasDos);
        jugadorDos.add(new JLabel("DAPOOS:"));
        damasDos = new JLabel(dapoos.jugadorSur().numeroDamas()+"", SwingConstants.CENTER);
        jugadorDos.add(damasDos);
        panelE.add(jugadorDos);
        fondo.add(panelE, BorderLayout.EAST);
    }   
    
    /*
     * preparar the tablero Elementos.
     */
    private void prepararElementosInformacion() {  
    	JPanel panelS = new JPanel();
    	panelS.setOpaque(false);
    	panelS.setLayout(new GridLayout(1, 3));
    	JPanel uno = new JPanel();
    	uno.setOpaque(false);
    	panelS.add(uno);
        informacion = new JPanel();
        informacion.setOpaque(false);
        informacion.setBorder(new CompoundBorder(new EmptyBorder(5, 5, 5, 5), new TitledBorder(new LineBorder(Color.black), "Información")));
        if (dificultad.equals("QuickTime")) informacion.setLayout(new GridLayout(2, 2));
        else informacion.setLayout(new GridLayout(1, 2));
        informacion.add(new JLabel("Turno:"));
        turno = new JLabel(dapoos.turno().nombre(), SwingConstants.CENTER);
        informacion.add(turno);
        panelS.add(informacion);
    	JPanel tres = new JPanel();
    	tres.setOpaque(false);
    	panelS.add(tres);
    	if (dificultad.equals("QuickTime")) {
        	informacion.add(new JLabel("Tiempo restante:"));
        	labelTimer = new JLabel(dapoos.seconds()+"", SwingConstants.CENTER);
        	informacion.add(labelTimer);
        	timer = new Timer();
    	}
    	fondo.add(panelS, BorderLayout.SOUTH);
    }   
    
    /*
     * preparar accions of TantFant.
     */
    private void prepararAcciones() {   
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        addWindowListener(new WindowAdapter(){
            @Override
            public void windowClosing(WindowEvent e) {
                accionSalir();
            }
        });
        prepararAccionesTablero();
        prepararAccionesMenu();
    } 
    
    /*
     * preparar menu accions.
     */
    private void prepararAccionesMenu() {   
        nuevo.addActionListener(e -> accionNuevo());
        abrir.addActionListener(e -> accionAbrir());
        guardar.addActionListener(e -> accionGuardar());
        salir.addActionListener(e -> accionSalir());
    }  
    
    /*
     * salir juego.
     */
    private void accionSalir() {   
        int respuesta = JOptionPane.showConfirmDialog(null, "¿Seguro que quieres salir del juego?", "Salir del juego", JOptionPane.OK_CANCEL_OPTION);
        if (respuesta == JOptionPane.OK_OPTION) {
            dispose();
            gui.setVisible(true);
        }
    }
    
    /*
     * reiniciar juego.
     */
    private void accionNuevo() {   
    	int respuesta = JOptionPane.showConfirmDialog(null, "¿Quieres guardar la partida actual?", "Nueva partida", JOptionPane.YES_NO_CANCEL_OPTION);
        if (respuesta == JOptionPane.YES_OPTION){
        	int respuesta2 = accionGuardar();
        	if (respuesta2 == JFileChooser.APPROVE_OPTION) {
        		reiniciar();
        	}
        } else if (respuesta == JOptionPane.NO_OPTION){
        	reiniciar();
        }
    }
    
    /*
     * Open game.
     */
    private void accionAbrir() {   
    	int respuesta = JOptionPane.showConfirmDialog(null, "¿Quieres guardar la partida actual?", "Abrir partida", JOptionPane.YES_NO_CANCEL_OPTION);
        int respuesta2 = JFileChooser.APPROVE_OPTION;
    	if (respuesta == JOptionPane.YES_OPTION) respuesta2 = accionGuardar();
        if (respuesta == JOptionPane.NO_OPTION || (respuesta == JOptionPane.YES_OPTION && respuesta2 == JFileChooser.APPROVE_OPTION)) {
            JFileChooser chooser = new JFileChooser();
            int open = chooser.showOpenDialog(null);
            if (open == JFileChooser.APPROVE_OPTION) {
                File file = chooser.getSelectedFile();
                JOptionPane.showMessageDialog(null, "La funcionalidad para abir el archivo " + file.getName() + " está en construcción.");
            }
        }
    }
    
    /*
     * Save game.
     */
    private int accionGuardar() {   
        JFileChooser chooser = new JFileChooser();
        int open = chooser.showSaveDialog(null);
        if (open == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            JOptionPane.showMessageDialog(null, "La funcionalidad para salvar el archivo " + file.getName() + " está en construcción.");
        }
        return open;
    }    
    
    /*
     * preparar tablero accions.
     */
    private void prepararAccionesTablero() {   
    	int tamano = Tablero.TAMANOLADO;
        for (int i = 0; i < tamano; i++) for (int j = 0; j < tamano; j++) {
        	if((i%2 == 0 && j%2 != 0) || (i%2 != 0 && j%2 == 0)) {
        		tablero[i][j].boton().addActionListener(e -> accionSeleccionar(e));
        	}
        }
        if (dificultad.equals("QuickTime")) {
	        timer.scheduleAtFixedRate(new TimerTask() {	
	        	public void run() {
	        		refrescarInformacion();
	        	}
	        }, 0, 1000);
        }
        if (visualizacion.equals("Relampago")) timerRelampagoTask();
    } 
    
    private void timerRelampagoTask() {
        timerRelampago.scheduleAtFixedRate(new TimerTask() {	
        	int s = 5;
        	public void run() {
        		s--;
        		if (s < 0) {
        			for (Casilla[] f:dapoos.tablero().casillas()) for (Casilla c:f) {
        				if (c != null) c.invisibilizar();
        			}
        			cancel();
        			refrescarCasillasEspeciales();
        		}
        	}
        }, 0, 1000);
    }
    
    /*
     * Seleccionar a box of the juego tablero.
     */
    private void accionSeleccionar(ActionEvent e) {  
        PanelCasilla boton = (PanelCasilla )((JButton)e.getSource()).getParent();
        String n = dapoos.turno().nombre();
        int r = boton.fila(), c = boton.columna();
        if (dapoos.tablero().casillas()[r][c].ficha() != null) {
        	try {
        		dapoos.tablero().seleccionar(dapoos.tablero().casillas()[r][c].ficha());
        		refrescar();
	            tablero[r][c].cambiarEstado('s');
	            ArrayList<int[]> mp = dapoos.tablero().seleccion().movimientosPosibles();
	            for (int[] m:mp) {
	            	tablero[m[0]][m[1]].cambiarEstado('p');
	                tablero[m[0]][m[1]].repaint();
	            }
	        } catch (DAPOOSException ex) {
				JOptionPane.showMessageDialog(null, ex.getMessage());
        	}	
        } else if (boton.estado() == 'p' && dapoos.tablero().seleccion() != null) {
        	try {
        		boolean m = dapoos.tablero().seleccion().mover(r, c);
        		dapoos.tablero().casillas()[r][c].activar();
        		if (m) JOptionPane.showMessageDialog(null, "Podía capturar, se ha capturado la ficha que no actuó.");
        		if (dapoos.tablero().bloqueado()) {
        			refrescar();
        			ArrayList<int[]> mp = dapoos.tablero().seleccion().movimientosPosibles();
                    for (int[] mo:mp) {
                    	tablero[mo[0]][mo[1]].cambiarEstado('p');
                    	tablero[mo[0]][mo[1]].repaint();
                    }
        		} else {
        			dapoos.tablero().seleccionar(null);
        			refrescar();
        		}
	        	if (dapoos.ganar()) {
	        		JOptionPane.showMessageDialog(null, "Ganó "+n+".");
	        		reiniciar();
	        	}
        	} catch (DAPOOSException ex) {
        		JOptionPane.showMessageDialog(null, ex.getMessage());
        	}
        }
        
    }
    
    /*
     * refrescar the tablero.
     */
    private void refrescarInformacion() {  
    	if (dapoos.seconds() == 0) refrescarTablero();
    	turno.setText(dapoos.turno()+"");
    	labelTimer.setText(dapoos.seconds()+"");  	
    } 
    
    /*
     * refrescar the tablero.
     */
    private void refrescarCasillasEspeciales() {   
    	int tamano = Tablero.TAMANOLADO;
        for(int i = 0; i < tamano; i++) for(int j = 0; j < tamano; j++) {
            tablero[i][j].repaint();
        }
    }    
    
    /*
     * refrescar the tablero.
     */
    private void refrescarTablero() {   
    	int tamano = Tablero.TAMANOLADO;
        for(int i = 0; i < tamano; i++) for(int j = 0; j < tamano; j++) {
            tablero[i][j].cambiarEstado('v');   
            tablero[i][j].repaint();
        }
    } 
    
    /*
     * refrescar the tablero.
     */
    private void refrescar() {   
    	movimientosUno.setText(dapoos.jugadorNorte().movimientos()+"");
    	movimientosDos.setText(dapoos.jugadorSur().movimientos()+"");
    	int numFichasNorte = dapoos.jugadorNorte().numeroFichas();
    	int numFichasSur = dapoos.jugadorSur().numeroFichas();
    	fichasUno.setText(numFichasNorte+"");
    	fichasDos.setText(numFichasSur+"");
    	capturasUno.setText(20-numFichasSur+"");
    	capturasDos.setText(20-numFichasNorte+"");
    	damasUno.setText(dapoos.jugadorNorte().numeroDamas()+"");
    	damasDos.setText(dapoos.jugadorSur().numeroDamas()+"");
    	turno.setText(dapoos.turno().nombre());
        refrescarTablero();
    } 
    
    /*
     * reiniciar juego.
     */
    private void reiniciar() {   
    	try {
    		if (visualizacion.equals("Relampago")) {
    			timerRelampago = new Timer();
    			timerRelampagoTask();
    		}
			dapoos = new DAPOOS(nombreUno, nombreDos, colorNorte, colorSur, porcentaje, dificultad, tiempo);
			refrescar();   
			
		} catch (DAPOOSException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
    }

    public DAPOOS dapoos() {
    	return dapoos;
    }
    
}
class PanelCasilla extends JPanel {
    private JButton boton;
    private int c, f;
    private char estado;
    private Juego Juego;
    /**
     * Constructor  for objects of class casilla.
     */
    public PanelCasilla(int f, int c, Juego Juego, JButton boton) {
        this.c = c;
        this.f= f;
        this.Juego = Juego;
        this.boton = boton;
    }
    
    /**
     * Paint the piece in the casilla.
     * @param g Graphics.
     */
    @Override
    public void paint(Graphics g){
    	Casilla casilla = Juego.dapoos().tablero().casillas()[f][c];
    	super.paint(g);
    	if (boton != null) {
    		Ficha ficha = Juego.dapoos().tablero().casillas()[f][c].ficha();
    		setBackground(Color.lightGray);
    		Ficha seleccionada = Juego.dapoos().tablero().seleccion();
    		if (ficha != null) {
    			Image piece = new ImageIcon(getClass().getResource("Imagenes/"+ficha.toString()+".png")).getImage();
				g.drawImage(piece, 0, 0, getWidth(), getHeight(), this);
    			if (estado == 's') setBackground(Color.gray);
    		} else if (ficha == null && estado == 'p' && seleccionada != null) {
    			Image piece = new ImageIcon(getClass().getResource("Imagenes/"+seleccionada.toString()+"Transparente.png")).getImage();
    			g.drawImage(piece, 0, 0, getWidth(), getHeight(), this);
    		}
    		if (casilla.visible() && casilla.toString() != "Casilla") {
    			Image piece = new ImageIcon(getClass().getResource("Imagenes/"+casilla.toString()+".png")).getImage();
        		g.drawImage(piece, 0, 0, getWidth(), getHeight(), this);
    		}	
    	}
    }


    
    /**
     * Give the boton of the casilla.
     * @return boton.
     */
    public JButton boton() {
        return boton;
    }
    
    /**
     * Gives the fila where the casilla is located.
     * @return fila number.
     */
    public int fila() {
        return f;
    }
    
    /**
     * Gives the columna where the casilla is located.
     * @return columna number.
     */
    public int columna() {
        return c;
    }
    
    /**
     * Gives the columna where the casilla is located.
     * @return columna number.
     */
    public void cambiarEstado(char m) {
        estado = m;
    }
    
    /**
     * Gives the columna where the casilla is located.
     * @return columna number.
     */
    public char estado() {
        return estado;
    }
}