package presentation;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;

import javax.swing.*;
import javax.swing.border.LineBorder;

public class DAPOOSGUI extends JFrame{
	
	JButton nuevo, abrir, opciones, salir, ayuda;

	public DAPOOSGUI() {
		super("Inicio daPOOs");
		prepararElementos();
		prepararAcciones();
	}
    /*
     * preparar the Elementos with which the user interacts.
     */
    private void prepararElementos() {   
    	setSize(1045, 665);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        setResizable(false);
        Fondo fondo = new Fondo("Inicio");
        Font fuente = new Font("Perpetua", 0, 30);
        Cursor cursor = new Cursor(Cursor.HAND_CURSOR);
        LineBorder borde = new LineBorder(Color.black, 2);
        fondo.setLayout(null);
        nuevo = new JButton("Nuevo Juego");
        nuevo.setBounds(390, 264, 260, 45);
        nuevo.setCursor(cursor);
        nuevo.setBackground(Color.white);
        nuevo.setBorder(borde);
        nuevo.setFont(fuente);
        abrir = new JButton("Abrir Juego");
        abrir.setBounds(390, 318, 260, 45);
        abrir.setCursor(cursor);
        abrir.setBackground(Color.white);
        abrir.setBorder(borde);
        abrir.setFont(fuente);
        opciones = new JButton("Opciones");
        opciones.setBounds(390, 372, 260, 45);
        opciones.setCursor(cursor);
        opciones.setBackground(Color.white);
        opciones.setBorder(borde);
        opciones.setFont(fuente);
        salir = new JButton("Salir");
        salir.setBounds(390, 427, 260, 45);
        salir.setCursor(cursor);
        salir.setBackground(Color.white);
        salir.setBorder(borde);
        salir.setFont(fuente);
        ayuda = new JButton("Ayuda");
        ayuda.setBounds(390, 481, 260, 45);
        ayuda.setCursor(cursor);
        ayuda.setBackground(Color.white);
        ayuda.setBorder(borde);
        ayuda.setFont(fuente);
        fondo.add(nuevo);
        fondo.add(abrir);
        fondo.add(salir);
        fondo.add(opciones);
        fondo.add(ayuda);  
        add(fondo);
    } 
    
    
    /*
     * preparar accions of TantFant.
     */
    private void prepararAcciones(){   
    	setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter(){
            @Override
            public void windowClosing(WindowEvent e){
                accionSalir();
            }
        });
        nuevo.addActionListener(e -> accionNuevo());
        salir.addActionListener(e -> accionSalir());
        abrir.addActionListener(e -> accionAbrir());
        opciones.addActionListener(e -> accionOpciones());
        ayuda.addActionListener(e -> accionAyuda());
    } 
    
    /*
     * salir colores configuration.
     */
    private void accionSalir() {   
        int respuesta = JOptionPane.showConfirmDialog(null, "¿Seguro que quieres salir del juego?", "Salir del juego", JOptionPane.OK_CANCEL_OPTION);
        if (respuesta == JOptionPane.OK_OPTION){
            setVisible(false);
            System.exit(0);
        }
    } 
    
    /*
     * salir colores configuration.
     */
    private void accionNuevo() {   
        new OpcionesJuego(this);
    } 
    
    /*
     * Open game.
     */
    private void accionAbrir() {   
        JFileChooser chooser = new JFileChooser();
        int open = chooser.showOpenDialog(null);
        if (open == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            JOptionPane.showMessageDialog(null, "La funcionalidad para abir el archivo " + file.getName() + " está en construcción.");
        }
    }
    
    /*
     * salir colores configuration.
     */
    private void accionOpciones() {   
    	JOptionPane.showMessageDialog(null, "La funcionalidad de opciones está en construcción.");
    } 
    
    /*
     * salir colores configuration.
     */
    private void accionAyuda() {   
    	JOptionPane.showMessageDialog(null, "La funcionalidad de ayuda está en construcción.");
    } 
    
	 /**
	 * Main method of TantFant.
	 */
	public static void main(String[] args) {
		DAPOOSGUI gui = new DAPOOSGUI();
	    gui.setVisible(true);
	} 
}

