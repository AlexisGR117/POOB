package domain;

import java.awt.Color;
import java.util.*;

/**
 * Tablero del juego DAPOOS.
 * @author Angel Cuervo y Jefer Gonzalez
 * @version 1.0 (19/11/2022)
 */
public class Tablero {
	
	public static final int TAMANOLADO = 10;
	public static final Color COLORUNO = Color.white;
	public static final Color COLORDOS = Color.lightGray;
	private Casilla[][] casillas;
	private DAPOOS dapoos;
	private Ficha seleccion;
	private boolean bloqueado;
	
	/**
	 * Constructor para objetos de clase Tablero.
	 * @param dapoos Juego de DAPOOS.
	 * @param porcentaje Porcentage de casillas especiales que va a tener el tablero.
	 */
	public Tablero(DAPOOS dapoos, int porcentaje) {
		this.dapoos = dapoos;
		casillas = new Casilla[TAMANOLADO][TAMANOLADO];
		Casilla casilla;
		for (int i = 0; i < TAMANOLADO; i++) for (int j = 0; j < TAMANOLADO; j++) {
			if((i%2 == 0 && j%2 != 0) || (i%2 != 0 && j%2 == 0)) {
				casilla = new Casilla(this, i, j);
				if (i < TAMANOLADO/2 - 1) casilla.colocarFicha(new Peon(dapoos.jugadorNorte()));
				else if (i > TAMANOLADO/2) casilla.colocarFicha(new Peon(dapoos.jugadorSur()));
				casillas[i][j] = casilla;
			}
		}
		int p = (int)((double)TAMANOLADO*((double)porcentaje/(double)100));
		ArrayList<Casilla> vacias = casillasVacias();
		while (p > 0) {
			Casilla c = vacias.get((int)(Math.random()*(vacias.size())));
			int t = (int)(Math.random()*(3)), fila = c.fila(), columna = c.columna();
			if (t == 0) casillas[fila][columna] = new Teleport(this, fila, columna);
			else if (t == 1) casillas[fila][columna] = new Jail(this, fila, columna);
			else casillas[fila][columna] = new Mine(this, fila, columna);
			vacias.remove(c);
			p--;
		}
	}
	
	/**
	 * Dice si una posicion dada está dentro del tablero.
	 * @param f Fila de la posición que se quiere verificar.
	 * @param c Columna de la posición que se quiere verificar.
	 * @return True si la posición esta dentro del tablero, de lo contario, False.
	 */
	public boolean dentro(int f, int c) {
		 return 0 <= f && f < TAMANOLADO && 0 <= c && c < TAMANOLADO;
	}
	
	/**
	 * Da las casillas que conforman el tablero.
	 * @return Una matriz con las casillas del tablero.
	 */
	public Casilla[][] casillas(){
		return casillas;
	}
	
	/**
	 * El juego DAPOOS el cual se está jugando en el tablero.
	 * @return Juego DAPOOS.
	 */
	public DAPOOS dapoos(){
		return dapoos;
	}
	
	/**
	 * Selecciona una ficha del tablero.
	 * @param ficha Ficha que se quiere seleccionar.
	 * @throws DAPOOSException 	INVALID_PLAYER, si no es el turno del jugador de la ficha que se seleccionada.
	 * 							ONE_TOKEN_PER_TURN, si se selecciona otra ficha cuando se acaba de capturar una ficha y se tiene otra posibilidad de capturar.
	 */
	public void seleccionar(Ficha ficha) throws DAPOOSException{
		if (ficha != null && ficha.jugador != dapoos.turno()) throw new DAPOOSException(DAPOOSException.INVALID_PLAYER);
		if (bloqueado && seleccion() != ficha) throw new DAPOOSException(DAPOOSException.ONE_TOKEN_PER_TURN);
		seleccion = ficha;
	}
	
	/**
	 * Retorna la ficha que actualemnte está seleccionada en el tablero.
	 * @return Ficha que está seleccionada en el tablero.
	 */
	public Ficha seleccion() {
		return seleccion;
	}
	
	/**
	 * Mueve la ficha que está seleccionada en el tablero a una posición dada.
	 * @param f Fila a la cual se quiere mover la ficha.
	 * @param c Columna a la cual se quiere mover la ficha.
	 * @throws DAPOOSException 	OFF_THE_BOARD, si a la posición a la cual se quiere mover no está dentro del tablero.
	 * 							WHITE_SQUARE, si a la posición que se quiere mover es una casilla blanca.
	 * 							NOT_EMPTY, si en la posición dada hay una ficha.
	 *							NOT_SELECTED, si no se tiene seleccionada una ficha en el tablero.
	 */
	public void moverSeleccion(int f, int c) throws DAPOOSException{
		if (!dentro(f, c)) throw new DAPOOSException(DAPOOSException.OFF_THE_BOARD);
		if (casillas()[f][c] == null) throw new DAPOOSException(DAPOOSException.WHITE_SQUARE);
		if (casillas()[f][c].ficha() != null) throw new DAPOOSException(DAPOOSException.NOT_EMPTY);
		if (seleccion == null) throw new DAPOOSException(DAPOOSException.NOT_SELECTED);
		seleccion.mover(f,  c);
	}
	
	/**
	 * Bloquea el tablero, lo cual significa que una ficha ha capturado y tiene la posibilidad de volver a capturar.
	 * Por lo tanto, no se cambia de turno y no se permite mover otras fichas que no sea la que ha capturado.
	 */
	public void bloquear() {
		bloqueado = true;
	}
	
	/**
	 * Desbloquea el tablero, permitiendo cambiar de turno y seleccionar otras fichas.
	 */
	public void desbloquear() {
		bloqueado = false;
	}
	
	/**
	 * Dice si el tablero está bloqueado.
	 * @return True si está blouqeado, de lo contrario False.
	 */
	public boolean bloqueado() {
		return bloqueado;
	}
	
	/**
	 * Retorna las casillas que no son blancas y no tienen fichas.
	 * @return Un ArrayList con las casillas vacias.
	 */
	public ArrayList<Casilla> casillasVacias(){
		ArrayList<Casilla> casillasVacias = new ArrayList<Casilla>();
		for (Casilla[] cf: casillas) for (Casilla c: cf) {
			if (c != null && c.ficha() == null) casillasVacias.add(c);
		}
		return casillasVacias;
	}
	
	@Override
	public String toString() {
		String s = "";
		for (Casilla[] c:casillas) {
			s += Arrays.toString(c) + "\n";
		}
		return s;
	}
}
