package domain;

public class Maquina extends Jugador{

	public Maquina(String nombre, String color, char lado) {
		super(nombre, color, lado);

	}

}
