package domain;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Versión modificada del juego clasico de mesa para dos jugadores, Damas.
 * @author Angel Cuervo y Jefer Gonzalez
 * @version 1.0 (19/11/2022)
 */
public class DAPOOS {
	
	private Jugador[] jugadores;
	private Tablero tablero;
	private Jugador turno;
	private Jugador ganador;
	private int seconds, tiempo;
	private String dificultad;
	private Timer timer;
	
	/**
	 * Constructor para objetos de clase DAPOOS.
	 * @param nombreUno Nombre del jugador norte.
	 * @param nombreDos Nombre del jugador sur.
	 * @param colorUno Color de las fichas del jugador norte.
	 * @param colorDos Color de las fichas del jugador sur.
	 * @param porcentaje Porcentaje de casillas especiales debe ser un valor entero entre 0 y 100.
	 * @param dificultad Dificultad del juego puede ser "Normal" o "QuickTime".
	 * @param tiempo Tiempo en segundos de cada turno, valido para la dificultad "QuickTime", puede ser un valor entre 0 y 100.
	 * @throws DAPOOSException	LONG_NAME, si alguno de los nombres tiene longitud mayor a 14.
	 * 						   	SHORT_NAME, si alguno de los nombres tiene longitud menor a 3.
	 * 							SAME_NAME, si los nombres de los juagdores son iguales.
	 * 							SAME_COLORS, si los colres de los jugadores son iguales.
	 * 							INVALID_PERCENTAGE, si el porcentage no es mayor a cero y menor que 100.
	 * 							INVALID_DIFFICULTY, si la dificultad dad no esta entre las establecidas que son "Normal" y "QuickTime".
	 * 							INVALID_TIME_TURN, si el modo es "QuickTime" y el tiempo de cada turno no está entre 0 y 100. 
	 */
	public DAPOOS(String nombreUno, String nombreDos, String colorUno, String colorDos, int porcentaje, String dificultad, int tiempo) throws DAPOOSException {
		if (nombreUno.length() > 14 || nombreDos.length() > 14) throw new DAPOOSException(DAPOOSException.LONG_NAME);
		if (nombreUno.length() < 3 || nombreDos.length() < 3) throw new DAPOOSException(DAPOOSException.SHORT_NAME);
		if (nombreUno.equals(nombreDos)) throw new DAPOOSException(DAPOOSException.SAME_NAMES);
		if (colorUno.equals(colorDos)) throw new DAPOOSException(DAPOOSException.SAME_COLORS);
		if (porcentaje < 0 || porcentaje > 100) throw new DAPOOSException(DAPOOSException.INVALID_PERCENTAGE);
		if (!(dificultad.equals("Normal") || dificultad.equals("QuickTime"))) throw new DAPOOSException(DAPOOSException.INVALID_DIFFICULTY);
		if (dificultad.equals("QuickTime") && (tiempo < 0 || tiempo > 100)) throw new DAPOOSException(DAPOOSException.INVALID_TIME_TURN);
		jugadores = new Jugador[2];
		jugadores[0] = new Jugador(nombreUno, colorUno, 'n');
		jugadores[1] = new Jugador(nombreDos, colorDos, 's');
		tablero = new Tablero(this, porcentaje);
		turno = jugadores[1];
		ganador = null;
		this.tiempo = tiempo;
		this.dificultad = dificultad;
    	if (this.dificultad.equals("QuickTime")) {
    		timer = new Timer();
			seconds = this.tiempo + 2;
	        timer.scheduleAtFixedRate(new TimerTask() {	
	        	public void run() {
	        		seconds--;
	        		if (seconds < 0) {
	        			try {
							cambiarTurno();
						} catch (DAPOOSException e) {}
	        		}		
	        	}
	        }, 0, 1000);
        }
 	}
    
	/**
	 * Da el tablero de un juego de DAPOOS.
	 * @return El tablero del juego.
	 */
	public Tablero tablero() {
		return tablero;
	}
	
	/**
	 * Retorna el jugador norte del juego de DAPOOS.
	 * @return El jugador del lado norte del tablero.
	 */
	public Jugador jugadorNorte() {
		return jugadores[0];
	}
	
	/**
	 * Retorna el jugador sur del juego de DAPOOS.
	 * @return El jugador del lado sur del tablero.
	 */
	public Jugador jugadorSur() {
		return jugadores[1];
	}
	
	/**
	 * Da el jugador que puede mover actualmente.
	 * @return El jugador que tiene el turno actual.
	 */
	public Jugador turno() {
		return turno;
	}
	
	/**
	 * Si el turno lo tenía el jugador norte, este pasa al juagdor sur, si no, todo lo contario.
	 * @throws DAPOOSException 	INVALID_PLAYER, si no es el turno del jugador de la ficha que se seleccionada.
	 * 							ONE_TOKEN_PER_TURN, si se selecciona otra ficha cuando se acaba de capturar una ficha y se tiene otra posibilidad de capturar.
	 */
	public void cambiarTurno() throws DAPOOSException {
		if (turno == jugadores[0]) turno = jugadores[1];
		else turno = jugadores[0];
		if (dificultad.equals("QuickTime")) {
			seconds = tiempo;
			if (seconds == 0) tablero.seleccionar(null);
		}
	}
	
	/**
	 * Dice si ya ganó alguien, ya sea por que se quedo sin fichas o sin movimientos.
	 * @return False si aún no ha ganado nadie, True si alguien ya ganó.
	 */
	public boolean ganar() {
		boolean g = false;
		if (jugadores[0].fichas().size() == 0 || (turno == jugadores[0] && jugadores[0].posiblesMovimientos() == 0)) {
			g = true;
			ganador = jugadores[1]; 
		}
		if (jugadores[1].fichas().size() == 0 || (turno == jugadores[1] && jugadores[0].posiblesMovimientos() == 1)) {
			g = true;
			ganador = jugadores[0]; 
		}
		return g;
	}
	
	/**
	 * El ganador del juego de DAPOOS.
	 * @return El jugador que gano el juego.
	 */
	public Jugador ganador() {
		return ganador;
	}
	
	/**
	 * Retorna los segundos que quedan actualmente del turno.
	 * @return Número de segundos que quedan del turno.
	 */
	public int seconds() {
		return seconds;
	}
}
