package domain;

public class DAPOOSException extends Exception {
	public static final String INVALID_MOVEMENT = "No se puede realizar el movimiento.";
    public static final String OFF_THE_BOARD = "La posición a la que se quiere mover la ficha no está dentro del tablero.";
    public static final String INVALID_PLAYER = "No es el turno de este jugador.";
    public static final String LONG_NAME = "El nombre de los jugadores debe tener menos de 14 caracteres.";
    public static final String SHORT_NAME = "El nombre de los jugadores debe tener al menos 3 caracteres.";
    public static final String SAME_NAMES = "Los nombres deben ser diferentes.";
    public static final String SAME_COLORS = "Los colores deben ser diferentes.";
    public static final String NOT_EMPTY = "En la posición a la cual se quiere mover la ficha no está vacía.";
    public static final String ONE_TOKEN_PER_TURN = "En un turno solo se puede mover una ficha.";
    public static final String WHITE_SQUARE = "Las fichas solo se pueden mover por las casillas negras.";
    public static final String NOT_SELECTED = "No se ha seleccionado una ficha en el tablero.";
    public static final String INVALID_PERCENTAGE = "El porcentaje debe ser un valor entre 0 y 100.";
    public static final String INVALID_DIFFICULTY = "Esta dificultad no está entre las establecidas que son: 'Normal' o QuickTime'.";
    public static final String INVALID_TIME_TURN = "El tiempo de cada turno debe ser un valor entre 0 y 100.";
    
    public DAPOOSException(String message) {
        super(message);
    }
}
