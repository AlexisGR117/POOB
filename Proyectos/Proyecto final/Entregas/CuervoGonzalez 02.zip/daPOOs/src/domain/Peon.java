package domain;
import java.util.*;

/**
 * Tipo de ficha que solo se puede mover de a una casilla y no se puede devolver.
 * @author Angel Cuervo y Jefer Gonzalez
 * @version 1.0 (19/11/2022)
 */
public class Peon extends Ficha {
	
	/**
	 * Constructor para objetos de clase Peon.
	 * @param jugador Jugador al cual pertenece la ficha.
	 */
	public Peon(Jugador jugador) {
		super(jugador);
	}
	
	/**
	 * Da las posibles posiciones a las que se puede mover el peón en el tablero.
	 * @return ArrayList con los movimientos posibles en arreglos donde en la posición 0 está la final y en la 1 la columna.
	 */
	public ArrayList<int[]> movimientosPosibles(){
		int fila = casilla.fila(), columna = casilla.columna();
		Tablero tablero = casilla.tablero();
		ArrayList<int[]> m = new ArrayList<int[]>();
		if (casilla.salir()) {
			Casilla[][] casillas = tablero.casillas();
			int a = 1;
			if (jugador.lado() == 's') a = -1;
			for (int dc=-1; dc<2;dc++){
	            if (dc!=0 && tablero.dentro(fila+a, columna+dc) && casillas[fila+a][columna+dc].ficha() == null) {
	        		int[] p = {fila+a, columna+dc};
	        		m.add(p);
	            }
			}
			m.addAll(saltosPosibles());
		}
		return m;
	}
	
	/**
	 * Da las posibles posiciones en las que el peón puede capturar al moverse.
	 * @return ArrayList con los saltos posibles en arreglos donde en la posición 0 está la final y en la 1 la columna.
	 */
	public ArrayList<int[]> saltosPosibles(){
		int fila = casilla.fila(), columna = casilla.columna();
		Tablero tablero = casilla.tablero();
		ArrayList<int[]> m = new ArrayList<int[]>();
		if (casilla.salir()) {
			Casilla[][] casillas = tablero.casillas();
			int a = 1;
			if (jugador.lado() == 's') a = -1;
			int b = 2 * a;
			for (int dc=-1; dc<2;dc++){
	            if (dc!=0 && tablero.dentro(fila+a, columna+dc) && casillas[fila+a][columna+dc].ficha() != null && casillas[fila+a][columna+dc].ficha().lado() != jugador.lado() &&
					tablero.dentro(fila+b, columna+dc*2) && casillas[fila+b][columna+dc*2].ficha() == null) {
	            	int[] p = {fila+b, columna+dc*2};
	            	m.add(p);
	            }
	        }
		}
		return m;
	}	
	
	@Override
	public boolean mover(int f, int c) throws DAPOOSException {
		boolean m = super.mover(f, c);
		if ((jugador.lado() == 'n' && casilla.fila() == Tablero.TAMANOLADO - 1) || (jugador.lado() == 's' && casilla.fila() == 0)) {
			jugador.fichas().remove(this);
			casilla.colocarFicha(new Dama(jugador));	
		}
		return m;
	}
	
	@Override
	public String toString() {
		return "Peon"+jugador.color();
	}
}
