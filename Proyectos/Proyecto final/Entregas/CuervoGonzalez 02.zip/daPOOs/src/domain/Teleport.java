package domain;

import java.util.ArrayList;

/**
 * Tipo de casilla que al colocar una ficha en ella, la ficha se teletransporta a una casilla vacia aleatoria en el tablero.
 * @author Angel Cuervo y Jefer Gonzalez
 * @version 1.0 (19/11/2022)
 */
public class Teleport extends Casilla{
	
	/**
	 * Constructor para objetos de tipo Teleport.
	 * @param tablero Tablero en el que está la casilla Teleport.
	 * @param fila Fila del tablero en la que está posicionada la casilla Telepor.
	 * @param columna Columna del tablero en la que está posicionada la casilla Teleport.
	 */
	public Teleport(Tablero tablero, int fila, int columna) {
		super(tablero, fila, columna);
	}
	
	@Override
	public void colocarFicha(Ficha ficha) {
		ArrayList<Casilla> casillasVacias = tablero().casillasVacias();
		Casilla c = casillasVacias.get((int)(Math.random()*(casillasVacias.size())));
		c.colocarFicha(ficha);
	}
	
	@Override
	public String toString() {
		return "Teleport";
	}
}
