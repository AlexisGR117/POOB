package domain;

import java.util.*;

/**
 * Jugador de un juego de DAPOOS.
 * @author Angel Cuervo y Jefer Gonzalez
 * @version 1.0 (19/11/2022)
 */
public class Jugador {
	
	private String color, nombre;
	private int movimientos, turnos;
	private char lado;
	private ArrayList<Ficha> fichas = new ArrayList<Ficha>();
	
	/**
	 * Constructor para objetos de clase Jugador.
	 * @param nombre Nombre del jugador.
	 * @param color Color del jugador.
	 * @param lado Lado del tablero del jugador.
	 */
	public Jugador(String nombre, String color, char lado) {
		this.nombre = nombre;
		this.color = color;
		this.lado = lado;
		movimientos = 0;
		turnos = 0;
	}
	 
	/**
	 * Dice si puede hacer alguna captura.
	 * @return Retorna la primera ficha que pueda hacer una captura.
	 */
	public Ficha posiblesCapturas() {
		Ficha f = null;
		for (int i = 0; i < fichas.size() && f == null; i ++) {
			if (fichas.get(i).numeroSaltosPosibles() > 0) f = fichas.get(i);
		}
		return f;
	}
	
	/**
	 * Los movimientos que el el jugador puede realizar con sus diferentes fichas.
	 * @return Número de movimientos que pueden realizar.
	 */
	public int posiblesMovimientos() {
		int pm = 0;
		for (int i = 0; i < fichas.size(); i ++) pm += fichas.get(i).numeroMovimientosPosibles();
		return pm;
	}
	
	/**
	 * Las fichas que tiene l jugador actualmente en le juego de DAPOOS.
	 * @return ArrayList con las fichas que tiene disponnibles el jugador.
	 */
	public ArrayList<Ficha> fichas() {
		return fichas;
	}
	
	/**
	 * Da el color que identifica al jugador en el juego.
	 * @return El color del jugador.
	 */
	public String color() {
		return color;
	}
	
	/**
	 * Da el nombre que identifica al jugador.
	 * @return El nombre del jugador.
	 */
	public String nombre() {
		return nombre;
	}
	
	/**
	 * Retorna el lado en el que esta ubicado el jugador en el tablero.
	 * @return 'n' si está en el lado norte o 's' si está en el lado sur.
	 */
	public char lado() {
		return lado;
	}
	
	/**
	 * Devuelve la cantidad de movimientos que ha hecho el jugado en el juego de DAPOOS.
	 * Un movimiento es cambiar una ficha de posición.
	 * @return Número de movimiento.
	 */
	public int movimientos() {
		return movimientos;
	}
	
	/**
	 * Da los turnos que ha tenido el jugador hasta ahora en el juego de DAPOOS.
	 * @return Número de turnos.
	 */
	public int turnos() {
		return turnos;
	}
	
	/**
	 * Suma uno al número de movimientos, representando que cambió de posición alguna ficha.
	 */
	public void nuevoMovimiento() {
		movimientos += 1;
	}
	
	/**
	 * Suma uno al número de turnos, representando que tuvo un turno nuevo.
	 */
	public void nuevoTurno() {
		turnos += 1;
	}
	
	/**
	 * Retorna la cantidad de fichas que actualmente tiene el jugador en la partida.
	 * @return Número de fichas del jugador en el tablero.
	 */
	public int numeroFichas() {
		return fichas.size();
	}
	 
	/**
	 * Devuelve la cantidad de fichas de tipo dama que actualmente tiene el jugador en la partida.
	 * @return Número de fichas de tipo dama del jugador en el tablero.
	 */	
	public int numeroDamas() {
		int n = 0;
		for (Ficha f:fichas) {
			if (f instanceof Dama) n += 1;
		}
		return n;
	}
	
	@Override
	public String toString() {
		return nombre;
	}
}
