import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.*;

/**
 * The test class ICPCContestTest.
 *
 * @author Angel Cuervo y Jefer Gonzalez.
 * @version 1.0 (18/09/2022)
 */
public class ICPCContestTest{
    @Test
    public void deberiaPoderSolucionarProblemasSoloAumentandoTodosLosLimitesAlMayorLimite(){
        ICPCContest contest = new ICPCContest();
        int[][] routesSpeedLimit = {{1, 2, 10}, {1, 3, 5}, {1, 4, 7}, {2, 5, 9}};
        assertEquals(9, contest.solve(100, routesSpeedLimit));
    }
    @Test
    public void deberiaPoderSolucionarProblemasSoloPoniendoSeñales(){
        ICPCContest contest = new ICPCContest();
        int[][] routesSpeedLimit = {{1, 2, 10}, {1, 3, 5}, {1, 4, 7}};
        assertEquals(6, contest.solve(2, routesSpeedLimit));
    } 
    @Test
    public void deberiaPoderSolucionarProblemasPoniendoSeñalesYAumentadoLimites(){
        ICPCContest contest = new ICPCContest();
        int[][] routesSpeedLimit = {{1, 2, 10}, {1, 3, 5}, {1, 4, 7}, {2, 5, 9}};
        assertEquals(7, contest.solve(2, routesSpeedLimit));
        int[][] routesSpeedLimit2 = {{1, 8, 101}, {1, 9, 30}, {1, 2, 100}, {1, 3, 100}, {2, 4, 75}, {2, 5, 70}, {2, 6, 82}, {2, 7, 77}, {3, 10, 73}, {3, 11, 69}, {3, 12, 83}, {3, 13, 79}};
        assertEquals(272, contest.solve(20, routesSpeedLimit2));
    } 
}