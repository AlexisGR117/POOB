import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class ICPCCC2Test.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ICPCCC2Test
{
    @Test
    public void accordingCGShouldCanConsultTotalSignsCost(){
        ICPC red = new ICPC(950, 950, 10);
        red.addIntersection("orange", 100, 800);
        red.addIntersection("green", 700, 0);
        red.addIntersection("yellow", 300, 600);
        red.addIntersection("red", 0, 50);
        red.addRoute("orange", "green");
        red.addRoute("green", "yellow"); 
        red.addRoute("yellow", "red");
        red.addRoute("red", "green");
        red.routeSpeedLimit("green", "orange", 5);
        red.putSign("green", "orange", 5);
        assertEquals(10, red.totalSignsCost());
        red.routeSpeedLimit("green", "yellow", 10);
        red.putSign("green", "yellow", 10);
        assertEquals(20, red.totalSignsCost());
        red.routeSpeedLimit("red", "yellow", 10);
        red.putSign("red", "yellow", 10);
        assertEquals(30, red.totalSignsCost());
        red.routeSpeedLimit("red", "green", 10);
        red.putSign("red", "green", 10);
        assertEquals(40, red.totalSignsCost());
        red.delIntersection("red");
        assertEquals(20, red.totalSignsCost());
        red.delRoute("yellow", "green");
        assertEquals(10, red.totalSignsCost());
        red.removeSign("orange", "green");
        assertEquals(0, red.totalSignsCost());
    }
}
