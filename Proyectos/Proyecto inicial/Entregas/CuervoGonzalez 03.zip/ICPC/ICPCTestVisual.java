

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class ICPCTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ICPCTestVisual{
    @Test
    public void pruebaVisual1()
    {
        ICPC mapa = new ICPC(950, 950);
        mapa.makeVisible();
        mapa.addIntersection("magenta", 100, 100);
        mapa.addIntersection("cyan", 275, 200);
        mapa.addIntersection("red", 450, 100);
        mapa.addIntersection("yellow", 100, 450);
        mapa.addIntersection("orange", 600, 700);
        mapa.addRoute("magenta", "cyan");
        mapa.addRoute("magenta", "yellow");
        mapa.addRoute("magenta", "red");
        mapa.addRoute("yellow", "cyan");
        mapa.addRoute("red", "cyan");
        mapa.addRoute("red", "yellow");
        mapa.addRoute("orange", "yellow");
        mapa.routeSpeedLimit("magenta", "cyan", 10);
        mapa.routeSpeedLimit("magenta", "yellow", 10);
        mapa.routeSpeedLimit("magenta", "red", 999);
        mapa.routeSpeedLimit("yellow", "cyan", 10);
        mapa.routeSpeedLimit("red", "cyan", 10);
        mapa.routeSpeedLimit("red", "yellow", 10);
        mapa.routeSpeedLimit("orange", "yellow", 5);
        mapa.putSign("yellow", "magenta", 7);
        mapa.putSign("cyan", "magenta", 5);
        mapa.putSign("yellow", "red", 9);
        mapa.putSign("magenta", "red", 999);
        mapa.putSign("cyan", "yellow", 15);
        mapa.putSign("cyan", "red", 20);
        mapa.putSign("orange", "yellow", 4);
        //mapa.delIntersection("orange");
        //mapa.delRoad("cyan", "yellow");
        //mapa.removeSign("red", "yellow");
        //mapa.makeInvisible();
        //{"red", "orange", "yellow", "red", "cyan", "magenta", "white", "lightGray", "gray", "darkGray", "blue", "black"};
        //{{1, 2, 10}, {1, 3, 20}, {1, 4, 7}, {2, 5, 10}, {3, 4, 12}, {6, 3, 20}}
    }
    
    @Test
    public void pruebaVisual2(){
        int[][] routesSpeedLimits = {{1, 2, 10}, {1, 3, 20}, {1, 4, 7}, {2, 5, 10}, {3, 4, 12}, {6, 3, 20}};
        ICPC mapa = new ICPC(12, routesSpeedLimits);
        mapa.makeVisible();
        mapa.putSign("red", "orange", 7);
        mapa.putSign("yellow", "red", 9);
        mapa.putSign("green", "red", 999);
        mapa.putSign("cyan", "orange", 15);
        mapa.putSign("magenta", "yellow", 20);
        mapa.putSign("green", "yellow", 4);
        //mapa.delIntersection("orange");
        //mapa.delRoad("cyan", "yellow");
        //mapa.removeSign("red", "yellow");
        //mapa.makeInvisible();
        //{"red", "orange", "yellow", "green", "cyan", "magenta", "white", "lightGray", "gray", "darkGray", "blue", "black"};
        // || higher == value.getSpeedLimit()
        //{{1, 2, 10}, {1, 3, 5}, {1, 4, 7}, {2, 5, 9}}
        //{{1, 8, 101}, {1, 9, 30}, {1, 2, 100}, {1, 3, 100}, {2, 4, 75}, {2, 5, 70}, {2, 6, 82}, {2, 7, 77}, {3, 10, 73}, {3, 11, 69}, {3, 12, 83}, {3, 13, 79}}
    }
}
