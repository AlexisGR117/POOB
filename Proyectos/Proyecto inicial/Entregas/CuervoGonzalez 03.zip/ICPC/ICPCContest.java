import java.util.*;
/**
 * Write a description of class ICPCContest here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ICPCContest
{
    boolean last;
    public int solve(int cost, int[][] routesSpeedLimit){
        int higher = higherRSL(routesSpeedLimit);
        int costChange = costChange(routesSpeedLimit, higher);
        ArrayList<Integer> intersections = intersections(routesSpeedLimit);
        HashMap<Integer, Integer[]> costs = costs(routesSpeedLimit, higher, cost, intersections);
        costs.forEach((key, value) -> {
           System.out.println(key + " " + Arrays.toString(value)); 
        });
        int minimum = minimum(costs, costChange);
        return minimum; 
    }
    
    public void simulate(int cost, int[][] routesSpeedLimit){
        ICPC red = new ICPC(cost, routesSpeedLimit);
        last = red.ok();
        int higher = higherRSL(routesSpeedLimit);
        int costChange = costChange(routesSpeedLimit, higher);
        ArrayList<Integer> intersections = intersections(routesSpeedLimit);
        HashMap<Integer, Integer[]> costs = costs(routesSpeedLimit, higher, cost, intersections);
        int minimum = minimum(costs, costChange);
        if(minimum != costChange){
            costs.forEach((k, v) -> {
                String color = color(k);
                if (v[0] < v[1] && v[0] >= 0){
                    red.getRoads().forEach((k2, v2)->{
                        int higher2 = higherRSL(routesSpeedLimit, k);
                        if(k2.contains(color) && v2.getSpeedLimit() != higher2){
                            v2.setSpeedLimit(higherRSL(routesSpeedLimit, k));
                            v2.changeColor("green"); 
                        }
                    });
                } else {
                    red.getRoads().forEach((k2, v2)->{
                        String[] colors = k2.split("-");
                        if(k2.contains(color)) red.putSign(colors[0], colors[1], v2.getSpeedLimit());
                    });
                }
            });
        } else {
            red.getRoads().forEach((k, v)->{
                if (v.getSpeedLimit() != higher){
                    v.setSpeedLimit(higher);
                    v.changeColor("green"); 
                }
            });
        }
        red.makeVisible();
    }
    
    public boolean ok(){
        return last;
    }
    
    private int higherRSL(int[][] routesSpeedLimit){
        int higher = 0;
        for(int[] rsl: routesSpeedLimit){
            higher = Math.max(higher, rsl[2]);
        }
        return higher;
    }
    
    private int higherRSL(int[][] routesSpeedLimit, int intersection){
        int higher = 0;
        for(int[] rsl: routesSpeedLimit){
            if(rsl[0] == intersection || rsl[1] == intersection){
                higher = Math.max(higher, rsl[2]);
            }
        }
        return higher;
    }
    
    private HashMap<Integer, Integer> numberRoutes(int[][] routesSpeedLimit){
        HashMap<Integer, Integer> nRoutes = new HashMap<Integer, Integer>();
        for(int[] rsl: routesSpeedLimit){
            if(!nRoutes.containsKey(rsl[0])) nRoutes.put(rsl[0], 0);
            if(!nRoutes.containsKey(rsl[1])) nRoutes.put(rsl[1], 0);
            nRoutes.put(rsl[0], nRoutes.get(rsl[0]) + 1);
            nRoutes.put(rsl[1], nRoutes.get(rsl[1]) + 1);
        }
        return nRoutes;
    }
    
    private ArrayList<Integer> intersections(int[][] routesSpeedLimit){
        ArrayList<Integer> intersections = new ArrayList<Integer>();
        for(int[] rsl: routesSpeedLimit){
            if(!intersections.contains(rsl[0])) intersections.add(rsl[0]);  
            if(!intersections.contains(rsl[1])) intersections.add(rsl[1]); 
        }
        return intersections;
    }
    
    private int costChange(int[][] routesSpeedLimit, int higher){
        int costChange = 0;
        for(int[] rsl: routesSpeedLimit){
            costChange += higher - rsl[2];
        }
        return costChange;
    }
    
    private int costChange(int[][] routesSpeedLimit, int higher, int intersection, HashMap<Integer, Integer> nRoutes){
        int costChange = 0;
        boolean notHigher = false;
        for(int[] rsl: routesSpeedLimit){
            if(rsl[0] == intersection || rsl[1] == intersection){
                costChange += higher - rsl[2];
                if(rsl[2] != higher){
                    if(rsl[0] != intersection && nRoutes.get(rsl[0]) > 1){
                        notHigher = true;
                    } else if (rsl[1] != intersection && nRoutes.get(rsl[1]) > 1){
                        notHigher = true;
                    }
                }
            }
        }   
        if(notHigher){
            costChange = -1;
        }
        return costChange;
    }
    
    private HashMap<Integer, Integer[]> costs(int[][] routesSpeedLimit, int higher, int cost, ArrayList<Integer> intersections){
        HashMap<Integer, Integer> nRoutes = numberRoutes(routesSpeedLimit);
        HashMap<Integer, Integer[]> costs = new HashMap<Integer, Integer[]>();
        for(int i: intersections){
            if(nRoutes.get(i) > 1){
                costs.put(i, new Integer[2]);
                int higher2 = higherRSL(routesSpeedLimit, i);
                int cost1 = costChange(routesSpeedLimit, higher2, i, nRoutes);
                int cost2 = nRoutes.get(i) * cost;
                costs.get(i)[0] = cost1;
                costs.get(i)[1] = cost2;
            }
        }
        return costs;
    }
    
    private int minimum(HashMap<Integer, Integer[]> costs, int costChange){
        int minimum = 0;
        Integer[] keysC = costs.keySet().toArray(new Integer[costs.size()]);
        for (Integer k:keysC){
            if (costs.get(k)[0] < costs.get(k)[1] && costs.get(k)[0] >= 0) minimum += costs.get(k)[0];
            else minimum += costs.get(k)[1];
        }
        if(costChange < minimum) minimum = costChange;
        return minimum;
    }
    
    private String color(int intersection){
        String color;
        if (intersection == 1) color = "red";
        else if (intersection == 2) color = "orange";
        else if (intersection == 3) color = "yellow";
        else if (intersection == 4) color = "green";
        else if (intersection == 5) color = "cyan";
        else if (intersection == 6) color = "magenta";
        else if (intersection == 7) color = "pink";
        else if (intersection == 8) color = "white";
        else if (intersection == 9) color = "blue";
        else if (intersection == 10) color = "lightGray";
        else if (intersection == 11) color = "gray";
        else if (intersection == 12) color = "darkGray";
        else  color = "black";
        return color;
    }
    
    private String order(String A, String B){
        String colors = B + "-" + A;
        if (A.compareTo(B) < 0){
            colors =  A + "-" + B;
        }
        return colors;
    }
}