import java.util.*;
/**
 * Intersecciones de la red de carreteras de ICPC.
 * 
 * @author Angel Cuervo y Jefer Gonzalez 
 * @version 1.0 (31/08/2022)
 */
public class Intersection{
    private String color;
    private ArrayList<Circle> circles = new ArrayList<Circle>();
    private boolean isVisible;
    private int xPosition;
    private int yPosition;
    /**
     * Contructor para objetos de clase Intersection.
     * @param color Color con el que se identifica la intersección.
     * @param x Posición en x de la intersección.
     * @param y Posición en y de la intersección.
     */
    public Intersection(String color, int x, int y){
        xPosition = x;
        yPosition = y;
        this.color = color;
        isVisible = false;
        circles.add(new Circle());
        circles.add(new Circle());
        circles.get(0).changeSize(50);
        circles.get(0).changeColor("black");
        circles.get(1).changeSize(40);
        circles.get(1).changeColor(color);
        circles.get(0).moveHorizontal(x);
        circles.get(0).moveVertical(y);
        circles.get(1).moveHorizontal(x+5);
        circles.get(1).moveVertical(y+5);
    }
    
    /**
     * Da la posición horizontal en la que se encuentra a intersección.
     * @return Retorna la posición de la intersección en el eje x.
     */
    public int getXPosition(){
        return xPosition;
    }
    
    /**
     * Da la posición vertical en la que se encuentra a intersección.
     * @return Retorna la posición de la intersección en el eje y.
     */
    public int getYPosition(){
        return yPosition;
    }
    
    public String getColor(){
        return color;
    }
    
    /**
     * Hace visible la intersección.
     */
    public void makeVisible(){
        isVisible = true;
        draw();
    }
    
    /**
     * Hace invisible la intersección.
     */
    public void makeInvisible(){
        erase();
        isVisible = false;
    }
    
    /*
     * Dibuja en la pantalla la interseccion.
     */
    private void draw() {
        if(isVisible) {
            circles.get(0).makeVisible();
            circles.get(1).makeVisible();
        } 
    }
    
    /*
     * Borra de la pantalla la interseccion.
     */
    private void erase(){
        if(isVisible) {
            circles.get(0).makeInvisible();
            circles.get(1).makeInvisible();
        } 
    }
}
