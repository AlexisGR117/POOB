import java.util.*;
import java.awt.Color;
import javax.swing.JOptionPane;
import java.lang.Math;
/**
 * Simulación inspirada en el Problem B de la maratón de programación internacional 2020 The Cost of Speed Limits.
 * 
 * @author Angel Cuervo y Jefer Gonzalez 
 * @version 1.0 (31/08/2022)
 */
public class ICPC{
    private HashMap<String, Intersection> intersection = new HashMap<String, Intersection>();
    private HashMap<String, Road> road = new HashMap<String, Road>();
    private HashMap<String, Sign> sign = new HashMap<String, Sign>();
    private ArrayList<String> wrongSign = new ArrayList<String>();
    private ArrayList<String> unNecessarySign = new ArrayList<String>();
    private boolean isVisible;
    private boolean last;
    private int sizeL;
    private int sizeW;
    private int signalCost;

    /**
     * Constructor para objetos de clase ICPC.
     * @param length Largo de la red ICPC.
     * @param width Ancho de la red ICPC.
     */
    public ICPC(int length, int width){
        Canvas canvas = Canvas.getCanvas(width + 50, length + 50);
        sizeL = length;
        sizeW = width;
        last = true;
    }

    /**
     * Constructor para objetos de clase ICPC
     * @param length Largo de la red ICPC.
     * @param width Ancho de la red ICPC.
     * @param cost Costo de las señales de la red ICPC.
     */
    public ICPC(int length, int width, int cost){
        Canvas canvas = Canvas.getCanvas(width + 50, length + 50);
        sizeL = length;
        sizeW = width;
        signalCost = cost;
        last = true;
    }
    
    /**
     * Constructor para objetos de clase ICPC
     * @param cost Costo de las señales de la red ICPC.
     * @param routesSpeedLimits Información definida en el Problem B.
     */
    public ICPC(int cost, int[][] routesSpeedLimits){
        Canvas canvas = Canvas.getCanvas(1000, 1000);
        sizeL = 950;
        sizeW = 950;
        signalCost = cost;
        String[] colors = {"red", "orange", "yellow", "green", "cyan", "magenta", "white", "lightGray", "gray", "darkGray", "blue", "black"};
        ArrayList<Integer> intersections = new ArrayList<Integer>();
        for (int i = 0; i < routesSpeedLimits.length; i++){
            String colorOne = colors[routesSpeedLimits[i][0]-1];
            String colorTwo = colors[routesSpeedLimits[i][1]-1];
            if (!intersections.contains(routesSpeedLimits[i][0])){
                addIntersection(colorOne, (int)(Math.random()*951), (int)(Math.random()*951)); 
            }
            if (!intersections.contains(routesSpeedLimits[i][1])){
                addIntersection(colorTwo, (int)(Math.random()*951), (int)(Math.random()*951)); 
            }
            addRoute(colorOne, colorTwo);
            routeSpeedLimit(colorOne, colorTwo, routesSpeedLimits[i][2]);
        }
        last = true;
    }    
    
    /**
     * Añade una nueva intersección a la red de carreteras de ICPC.
     * @param color Color que identifica a la intersección.
     * @param x Poscición en el eje x de la intersección.
     * @param y Poscición en el eje y de la intersección.
     */
    public void addIntersection(String color, int x, int y){
        boolean used = existI(color);
        if ((0 <= x && x <= sizeW && 0 <= y && y <= sizeL) && Canvas.existColor(color) && !used){
            erase();
            intersection.put(color, new Intersection(color, x, y)); 
            draw();
            last = true;
        } else{
            last = false;
            if (isVisible){
                JOptionPane.showMessageDialog(null, "No se pudo realizar la acción.");
                if (!(0 <= x && x <= sizeW)){
                    JOptionPane.showMessageDialog(null, "La posición en x de la intersección se sale de la red ICPC.");  
                }
                if (!(0 <= y && y <= sizeL)){
                    JOptionPane.showMessageDialog(null, "La posición en y de la intersección se sale de la red ICPC.");  
                }
                if (!Canvas.existColor(color)){
                    JOptionPane.showMessageDialog(null, "El color dado no está dentro de la opciones de Canvas.");  
                }
                if (used){
                    JOptionPane.showMessageDialog(null, "El color dado ya está siendo usado por otra intersección.");  
                }
            }
        }
    }
    
    /**
     * Agrega una nueva ruta a la red de carreteras de ICPC dada dos intersecciones existentes.
     * @param intersectionA Color de la primera intersección a la cuál llega la ruta.
     * @param intersectionB Color de la segunda intersección a la cuál llega la ruta.
     */
    public void addRoute(String intersectionA, String intersectionB){
        String colors = order(intersectionA, intersectionB);
        boolean used = existR(colors);
        boolean existA = existI(intersectionA);
        boolean existB = existI(intersectionB);  
        if (!intersectionA.equals(intersectionB) && !used && existA && existB){
            erase();
            road.put(colors, new Road(intersection.get(intersectionA).getXPosition(),
                                     intersection.get(intersectionA).getYPosition(),
                                     intersection.get(intersectionB).getXPosition(),
                                     intersection.get(intersectionB).getYPosition()));
            draw();
            last = true;
        } else{
            last = false;
            if (isVisible){
                JOptionPane.showMessageDialog(null, "No se pudo realizar la acción.");
                if (intersectionA.equals(intersectionB)){
                    JOptionPane.showMessageDialog(null, "Las intersecciones deben ser diferentes.");  
                }
                if (!existA){
                    JOptionPane.showMessageDialog(null, "La primera intersección no existe.");  
                }
                if (!existB){
                    JOptionPane.showMessageDialog(null, "La segunda intersección no existe.");  
                }
                if (used){
                    JOptionPane.showMessageDialog(null, "Las intersecciones dadas ya tienen ruta.");  
                }
            }
        }
    }
    
    /**
     * Asigna un límite de velocidad a una ruta.
     * @param intersectionA Color de la primera intersección a la cuál llega la ruta.
     * @param intersectionB Color de la segunda intersección a la cuál llega la ruta.
     * @param speedLimit Límite de velocidad de la ruta.
     */
    public void routeSpeedLimit(String intersectionA, String intersectionB, int speedLimit){
       String colors = order(intersectionA, intersectionB);
       road.get(colors).setSpeedLimit(speedLimit);
    }
    
    /**
     * Pone una nueva señal de límite de velocidad a la red de carreteras de ICPC.
     * @param intersectionA Color de la primera intersección que conforma la ruta.
     * @param intersectionB Color de la segunda intersección que conforma la ruta.
     * @param speddLimit Velocidad máxima que va a tener la carretera.
     */
    public void putSign(String intersectionA, String intersectionB, int speedLimit){
        String colors = order(intersectionA, intersectionB);
        boolean used = existS(colors);
        boolean existR = existR(colors);
        boolean existRSL = false;
        if (existR){
            existRSL = existRSL(colors);
        }
        if (!used && existRSL && speedLimit < 1000){
            erase();
            sign.put(colors, new Sign(speedLimit, intersection.get(intersectionA).getXPosition(),
                                                  intersection.get(intersectionA).getYPosition(),
                                                  intersection.get(intersectionB).getXPosition(),
                                                  intersection.get(intersectionB).getYPosition()));
            if (speedLimit > road.get(colors).getSpeedLimit()){
                wrongSign.add(colors);
                sign.get(colors).changeColorNumber("red");
            }
            necessary(colors);
            draw();
            last = true;
        } else{
            last = false;
            if (isVisible){
                JOptionPane.showMessageDialog(null, "No se pudo realizar la acción.");
                if (!existR){
                    JOptionPane.showMessageDialog(null, "La carretera con las intersecciones dadas no existe.");  
                }
                if (!existRSL && existR){
                    JOptionPane.showMessageDialog(null, "La carretera no tiene asignada un límite de velocidad.");  
                }
                if (speedLimit >= 1000){
                    JOptionPane.showMessageDialog(null, "El límite de velocidad no debe ser mayor o igual a 1000.");  
                }
                if (used){
                    JOptionPane.showMessageDialog(null, "La ruta dada ya tiene una señal de límite de velocidad.");  
                }
            }
        }
    }

    /**
     * Elimina una intersección de la red de carreteras de ICPC.
     * @param color Color con el que se identifica la intersección que se va a eliminar.
     */
    public void delIntersection(String color){
        boolean used = existI(color);
        if (used){
            erase();
            intersection.remove(color);
            delRoutes(color);
            delSigns(color);
            sign.forEach((key, value) -> {
                necessary(key); 
            });
            draw();
            last = true;
        } else {
            last = false;
            if (isVisible){
                JOptionPane.showMessageDialog(null, "No se pudo realizar la acción.");
                if (!used){
                    JOptionPane.showMessageDialog(null, "El color dado no está siendo usado por una intersección.");  
                }
            }
        }   
    }
    
    /**
     * Elimina una carretera de la red de carreteras de ICPC.
     * @param intersectionA Color de la primera intersección que conforma al ruta.
     * @param intersectionB Color de la segunda intersección que conforma al ruta.
     */
    public void delRoute(String intersectionA, String intersectionB){
        String colors = order(intersectionA, intersectionB);
        boolean used = existR(colors);
        //exist route
        if (used){
            erase();
            //delete route
            delRoutes(colors);
            delSigns(colors);
            draw();
            sign.forEach((key, value) -> {
                if (key.contains(intersectionA) || key.contains(intersectionB)){
                    necessary(key);
                }
            });
            last = true;
        } else {
            last = false;
            if (isVisible){
                JOptionPane.showMessageDialog(null, "No se pudo realizar la acción");
                if (!used){
                    JOptionPane.showMessageDialog(null, "No existe la carretera con las intersecciones dadas.");  
                }
            }
        }
    }
    
    /**
     * Quita una señal de límite de velocidad a la red de carreteras de ICPC.
     * @param intersectionA Color de la primera intersección que conforma al ruta donde está ubicada la señal.
     * @param intersectionB Color de la segunda intersección que conforma al ruta donde está ubicada la señal.
     */
    public void removeSign(String intersectionA, String intersectionB){
        String colors = order(intersectionA, intersectionB);
        boolean used = existS(colors);
        if (used){
            erase();
            delSigns(colors);
            draw();
            last = true;
        } else {
            last = false;
            if (isVisible){
                JOptionPane.showMessageDialog(null, "No se pudo realizar la acción");
                if (!used){
                    JOptionPane.showMessageDialog(null, "No existe la señal en la carretera de las intersecciones dadas.");  
                }
            }
        }
    }
    
    /**
     * Da todas las intersecciones que se encuentran el la red de carreteras de ICPC.
     * @return Retorna un arreglo con los colores que se identifican las intersecciones.
     */
    public String[] intersections(){
        last = true;
        return inArray(intersection);
    }
    
    /**
     * Da todas las carreteras que se encuentran el la red de carreteras de ICPC.
     * @return Retorna un arreglo con los colores de las intersecciones que conforman la rutas.
     */
    public String[][] roads(){
        last = true;
        return inArrays(road);
    }
    
    /**
     * Da todas las señales de límite de velocidad que se encuentran el la red de carreteras de ICPC.
     * @return Retorna un arreglo con los colores de las intersecciones que conforman la rutas donde se encuentran las señales de límite de velocidad.
     */
    public String[][] signs(){
        last = true;
        //.keySet().toArray(
        return inArrays(sign);
    }

    /**
     * Da todas las señales de límite de velociad erroneas que se encuentran el la red de carreteras de ICPC.
     * @return Retorna un arreglo con los colores de las intersecciones que conforman la rutas donde se encuentran las señales de límite de velocidad erroneas.
     */
    public String[][] wrongSigns(){
        last = true;
        return inArrays(wrongSign);
    }    
    
    /**
     * Da todas las señales de límite de velociad innecesarias que se encuentran el la red de carreteras de ICPC.
     * @return Retorna un arreglo con los colores de las intersecciones que conforman la rutas donde se encuentran las señales de límite de velocidad innecesarias.
     */
    public String[][] unNecessarySigns(){
        last = true;
        return inArrays(unNecessarySign);
    }   
    
    /**
     * Da el costo total de las señales de la red de carreteras ICPC.
     * @return Costo total.
     */
    public int totalSignsCost(){
        last = true;
        return signalCost * sign.size();
    }   
    
    /**
     * Hace visible la red de carreteras de ICPC.
     */
    public void makeVisible(){
        isVisible = true;
        draw();
    }
    
    /**
     * Hace Invisible la red de carreteras de ICPC.
     */
    public void makeInvisible(){
        erase();
        isVisible = false;
    }
    
    /**
     * Termina el simulador de la red de carreteras de ICPC.
     */
    public void finish(){
        System.exit(0);
    }
    
    /**
     * Dice si la última acción se hizo o no.
     * @return Retorna si la última acción se pudo realizar o no.
     */
    public boolean ok(){
        return last;
    }
    
    /*
     * Borra de la pantalla la red de carreteras de ICPC.
     */
    private void erase(){
        if(isVisible) {
            intersection.forEach((key, value) -> {
                value.makeInvisible();
            });
            road.forEach((key, value) -> {
                value.makeInvisible();
            });
            sign.forEach((key, value) -> {
                value.makeInvisible();
            });
        }
    } 
    
    /*
     * Dibuja en la pantalla la red de carreteras de ICPC.
     */
    private void draw() {
        if(isVisible) {
            road.forEach((key, value) -> {
                value.makeVisible();
            });
            intersection.forEach((key, value) -> {
                value.makeVisible();
            });
            sign.forEach((key, value) -> {
                value.makeVisible();
            });
        }
    }   
    
    /*
     * Ordena dos cadenas alfabeticamente y las une con un guión.
     */
    private String order(String A, String B){
        String colors = B + "-" + A;
        if (A.compareTo(B) < 0){
            colors =  A + "-" + B;
        }
        return colors;
    }
    
    /*
     * Dice sí existe una intersección con ese color.
     */
    private boolean existI(String color){
        return intersection.containsKey(color);
    }
    
    /*
     * Dice sí existe una ruta que une dos intersecciones con esos colores.
     */
    private boolean existR(String colors){
        return road.containsKey(colors);
    }
    
    /*
     * Dice sí existe una señal en una ruta que une dos intersecciones con esos colores.
     */
    private boolean existS(String colors){
        return sign.containsKey(colors);
    }
    
    /*
     * Dice sí existe un límite de velocidad en la carretera dada.
     */
    private boolean existRSL(String colors){
        return road.get(colors).getSpeedLimit() != 0;
    }
    
    /*
     * Elimina todas las carreteras que tiene las intersecciones con el o los colores dados.
     */
    private void delRoutes(String color){
        String[] keysR = inArray(road);
        for (int i = 0; i < keysR.length; i++){
            if (keysR[i].contains(color)){
                    road.remove(keysR[i]); 
            }
        }       
    }
    
    /*
     * Elimina todas las señales de las carreteras que tienen las intersecciones con el o los colores dados.
     */
    private void delSigns(String color){
        String[] keysS = inArray(sign);
        for (int i = 0; i < keysS.length; i++){
            if (keysS[i].contains(color)){
                sign.remove(keysS[i]);
                if (unNecessarySign.contains(color)){
                    unNecessarySign.remove(color);
                }
                if (wrongSign.contains(color)){
                    wrongSign.remove(color);
                }
            }
        }
    }
    
    /*
     * Obtiene las llaves de las intersecciones en un arreglo de cadenas.
     */
    private String[] inArray(HashMap map){
        Set<String> keys = map.keySet();
        return keys.toArray(new String[0]);
    }
    
    /*
     * Obtiene las llaves de las carreteras y señales en un arreglo de arreglos.
     */
    private String[][] inArrays(HashMap map){
        Iterator<String> keysSet = map.keySet().iterator();
        String[][] keys = new String[map.size()][2];
        int i = 0;
        while (keysSet.hasNext()){
            String[] colors = keysSet.next().split("-");
            keys[i][0] = colors[0];
            keys[i][1] = colors[1];
            i ++;
        }
        return keys;
    }

    /*
     * Obtiene las intersecciones de las carreteras y señales en un arreglo de arreglos.
     */
    private String[][] inArrays(ArrayList<String> array){
        String[][] a = new String[array.size()][2];
        for (int i = 0; i < array.size(); i++){
            String[] colors = array.get(i).split("-");
            a[i][0] = colors[0];
            a[i][1] = colors[1];
            i ++;
        }
        return a;
    }
    
    /*
     * Dice si una señal de límite de velocidad es innecesaria, si lo es, entonces cambia su color y la añade a las señales innecesarias.
     */
    private void necessary(String colors){
        String[] color = colors.split("-"); 
        boolean unNecessary = true;
        String[] keysR = inArray(road);
        for (int i = 0; i < keysR.length && unNecessary; i++){
            if ((keysR[i].contains(color[0]) || keysR[i].contains(color[1])) && road.get(colors).getSpeedLimit() != road.get(keysR[i]).getSpeedLimit()){
                unNecessary = false;
            }
        }    
        if (unNecessary && !unNecessarySign.contains(colors)){
            unNecessarySign.add(colors);
            sign.get(colors).changeColorSign("orange");
        } else if (!unNecessary && unNecessarySign.contains(colors)){
            unNecessarySign.remove(colors);
        } 
    }
}