import java.awt.*;

/**
 * Un romboide que puede ser manipulado y representado en un canvas.
 * 
 * @author Angel Cuervo y Jefer Gonzalez 
 * @version 1.0 (31/08/2022)
 */
public class Rhomboid{
    private int side;
    private int xPosition1;
    private int yPosition1;
    private int xPosition2;
    private int yPosition2;
    private String color;
    private boolean isVisible;

    /**
     * Crea un nueve romboide con unos tamaños, posición y color predefinidos.
     * @param x1 Posición en x del centro del primer lado recto.
     * @param y1 Posición en y del centro del primer lado recto.
     * @param x2 Posición en x del centro del segundo lado recto.
     * @param y2 Posición en y del centro del segundo lado recto.
     * @param side Longitud de los lados rectos.
     * @param color Color del romboide.
     */
    public Rhomboid(int x1,int y1,int x2,int y2, int side, String color){
        this.side = side;
        xPosition1 = x1;
        yPosition1 = y1;
        xPosition2 = x2;
        yPosition2 = y2;
        this.color = color;
        isVisible = false;
    }
    
    /**
     * Hace visible el romboide.
     */
    public void makeVisible(){
        isVisible = true;
        draw();
    }
    
    /**
     * Hace invisible el romboide.
     */
    public void makeInvisible(){
        erase();
        isVisible = false;
    }
    
    /*
     * Dibuja el romboide en la pantalla.
     */
    private void draw() {
         if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            if (Math.abs(xPosition1-xPosition2) > Math.abs(yPosition1-yPosition2)){
                int[] xpoints = {xPosition1, xPosition2, xPosition2, xPosition1};
                int[] ypoints = {yPosition1 + side/2, yPosition2 + side/2, yPosition2 - side/2, yPosition1 - side/2};
                canvas.draw(this, color, new Polygon(xpoints, ypoints, 4));
            } else {
                int[] xpoints = {xPosition1 + side/2, xPosition2 + side/2, xPosition2 - side/2, xPosition1 - side/2};
                int[] ypoints = {yPosition1, yPosition2, yPosition2, yPosition1};
                canvas.draw(this, color, new Polygon(xpoints, ypoints, 4)); 
            }
        }
    }

    /*
     * Borra el romboide de la pantalla.
     */
    private void erase(){
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
}
