

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class ICPCTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ICPCTest
{
    @Test
    public void tearDown()
    {
    ICPC mapa = new ICPC(1000, 1000);
    mapa.makeVisible();
    mapa.addIntersection("magenta", 100, 100);
    mapa.addIntersection("cyan", 275, 200);
    mapa.addIntersection("green", 450, 100);
    mapa.addIntersection("yellow", 100, 450);
    mapa.addIntersection("orange", 600, 700);
    mapa.addRoute("magenta", "cyan");
    mapa.addRoute("magenta", "yellow");
    mapa.addRoute("magenta", "green");
    mapa.addRoute("yellow", "cyan");
    mapa.addRoute("green", "cyan");
    mapa.addRoute("green", "yellow");
    mapa.addRoute("orange", "yellow");
    mapa.routeSpeedLimit("magenta", "cyan", 10);
    mapa.routeSpeedLimit("magenta", "yellow", 10);
    mapa.routeSpeedLimit("magenta", "green", 10);
    mapa.routeSpeedLimit("yellow", "cyan", 10);
    mapa.routeSpeedLimit("green", "cyan", 10);
    mapa.routeSpeedLimit("green", "yellow", 10);
    mapa.routeSpeedLimit("orange", "yellow", 5);
    mapa.putSign("yellow", "magenta", 7);
    mapa.putSign("cyan", "magenta", 5);
    mapa.putSign("yellow", "green", 9);
    mapa.putSign("magenta", "green", 10);
    mapa.putSign("cyan", "yellow", 15);
    mapa.putSign("cyan", "green", 20);
    mapa.putSign("orange", "yellow", 4);
    mapa.delIntersection("orange");
    //mapa.delRoad("cyan", "yellow");
    //mapa.removeSign("green", "yellow");
    //mapa.makeInvisible();
    //{"red", "orange", "yellow", "green", "cyan", "magenta", "white", "lightGray", "gray", "darkGray", "blue", "black"};
    //{{1, 2, 10}, {1, 3, 20}, {1, 4, 7}, {2, 5, 10}, {3, 4, 12}, {6, 3, 20}}
    }
}
