

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class ICPCC2Test.
 *
 * @author Angel Cuervo y Jefer Gonzalez.
 * @version 1.0 (18/09/2022)
 */
public class ICPCC2Test
{
    @Test
    public void deberiaPoderCrearRedesConInformacion(){
        int[][] routesSpeedLimits = {{1, 2, 10}, {1, 3, 20}, {1, 4, 7}, {2, 5, 10}, {3, 4, 12}, {6, 3, 20}};
        ICPC red = new ICPC(10, routesSpeedLimits);
        assertTrue(red.ok());
        assertEquals(red.intersections().length, 6);
        assertEquals(red.roads().length, 6);
    }    
    
    @Test
    public void deberiaPoderCrearIntersecciones(){
        ICPC red = new ICPC(1000, 1000);
        red.addIntersection("orange", 100, 200);
        assertTrue(red.ok());
        assertEquals(red.intersections().length, 1);
    }
    
    @Test
    public void noDeberiaPermitirCrearAlgunasIntersecciones(){
        ICPC red = new ICPC(1000, 1000);
        red.addIntersection("orange", 1001, 200);
        assertFalse(red.ok());
        assertEquals(red.intersections().length, 0);
        red.addIntersection("orange", 100, 10001);
        assertFalse(red.ok());
        assertEquals(red.intersections().length, 0);
        red.addIntersection("orange", 100, 200);
        red.addIntersection("orange", 300, 500);
        assertFalse(red.ok());
        assertEquals(red.intersections().length, 1);
        red.addIntersection("naranja", 100, 200);
        assertFalse(red.ok());
        assertEquals(red.intersections().length, 1);
    }
}
