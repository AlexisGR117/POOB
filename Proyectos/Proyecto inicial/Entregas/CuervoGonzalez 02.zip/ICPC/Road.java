import java.util.*;
/**
 * Carreteras de la red de carreteras de ICPC.
 * 
 * @author Angel Cuervo y Jefer Gonzalez 
 * @version 1.0 (31/08/2022)
 */
public class Road{
    private ArrayList<Rhomboid> rhomboids = new ArrayList<Rhomboid>();
    private int speedLimit;
    private boolean isVisible;
    
    /**
     * Constructor para objetos de clase Road.
     * @param x1 Posición en x de la primera intersección.
     * @param y1 Posición en y de la primera intersección.
     * @param x2 Posición en x de la segunda intersección.
     * @param y2 Posición en y de la segunda intersección. 
     */
    public Road(int x1,int y1,int x2,int y2){
        rhomboids.add(new Rhomboid(x1+25, y1+25, x2+25, y2+25, 30, "black"));
        rhomboids.add(new Rhomboid(x1+25, y1+25, x2+25, y2+25, 20, "white"));
    }
    
    /**
     * Asigna un límite de velocidad a la carretera.
     * @param s Límite de velocidad.
     */
    public void setSpeedLimit(int s){
        speedLimit = s;
    }
    
    /**
     * Devuelve el límite de velocidad que tiene la carretera.
     * @return El límite de velocidad.
     */
    public int getSpeedLimit(){
        return speedLimit;
    }

    /**
     * Hace visible la carretera.
     */
    public void makeVisible(){
        isVisible = true;
        draw();
    }
    
    /**
     * Hace invisible la carretera.
     */
    public void makeInvisible(){
        erase();
        isVisible = false;
    }
    
    /*
     * Dibuja en la pantalla la carretera.
     */
    private void draw() {
        rhomboids.get(0).makeVisible();
        rhomboids.get(1).makeVisible();
    } 
    
    /*
     * Borra de la pantalla la carretera.
     */
    private void erase(){
        rhomboids.get(0).makeInvisible();
        rhomboids.get(1).makeInvisible();
    } 
}
