import java.awt.*;

/**
 * Un romboide que puede ser manipulado y representado en un canvas.
 * 
 * @author Angel Cuervo y Jefer Gonzalez 
 * @version 1.0 (31/08/2022)
 */
public class Rhomboid{
    private int side;
    private int height;
    private int xPosition;
    private int xDistance;
    private int yPosition;
    private String color;
    private boolean isVisible;

    /**
     * Crea un nueve romboide con unos tamaños, posición y color predefinidos.
     */
    public Rhomboid(){
        height = 20;
        side = 20;
        xPosition = 20;
        xDistance = 0;
        yPosition = 20;
        color = "blue";
        isVisible = false;
    }
    
    /**
     * Hace visible el romboide.
     */
    public void makeVisible(){
        isVisible = true;
        draw();
    }
    
    /**
     * Hace invisible el romboide.
     */
    public void makeInvisible(){
        erase();
        isVisible = false;
    }
    
    /**
     * Mueve horizontalmente el romboide.
     * @param distance La distancia deseada en pixeles.
     */
    public void moveHorizontal(int distance){
        erase();
        xPosition += distance;
        draw();
    }

    /**
     * Mueve verticalmente el romboide.
     * @param distance La distancia deseada en pixeles.
     */
    public void moveVertical(int distance){
        erase();
        yPosition += distance;
        draw();
    }

    /**
     * Cambia las medidas del romboide por unas nuevas.
     * @param newHeight La nueva altura en pixeles. newHeight debe ser >=0.
     * @param newWidht El nuevo tamaño del lado en pixeles. newWidth debe ser >=0.
     * @param newDistance La distancia horizontal que hay entre los vertices. newWidth debe ser >=0.
     */
    public void changeSize(int newHeight, int newSide, int newDistance) {
        erase();
        height = newHeight;
        side = newSide;
        xDistance= newDistance;
        draw();
    }
    
    /**
     * Cambia el color del romboide.
     * @param color El nuevo color.
     */
    public void changeColor(String newColor){
        color = newColor;
        draw();
    }
    
    /*
     * Dibuja el romboide en la pantalla.
     */
    private void draw() {
         if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            int[] xpoints = {xPosition, xPosition + side, xPosition + side + xDistance, xPosition + xDistance};
            int[] ypoints = {yPosition, yPosition, yPosition + height, yPosition + height};
            canvas.draw(this, color, new Polygon(xpoints, ypoints, 4));
        }
    }

    /*
     * Borra el romboide de la pantalla.
     */
    private void erase(){
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
}
