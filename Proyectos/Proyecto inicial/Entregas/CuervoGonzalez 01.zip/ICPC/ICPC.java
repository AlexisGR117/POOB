import java.util.*;
import java.awt.Color;
import javax.swing.JOptionPane;
/**
 * Simulación inspirada en el Problem B de la maratón de programación internacional 2020 The Cost of Speed Limits.
 * 
 * @author Angel Cuervo y Jefer Gonzalez 
 * @version 1.0 (31/08/2022)
 */
public class ICPC{
    private HashMap<String, Intersection> intersection = new HashMap<String, Intersection>();
    private HashMap<String[], Road> road = new  HashMap<String[], Road>();
    private HashMap<String[], Sign> sign = new  HashMap<String[], Sign>();
    private boolean isVisible;
    private boolean last;
    private int sizeL;
    private int sizeW;

    /**
     * Constructor para objetos de clase ICPC
     */
    public ICPC(int length, int width){
        Canvas canvas = Canvas.getCanvas(width, length);
        sizeL = length;
        sizeW = width;
        last = true;
    }

    /**
     * Añade una nueva intersección a la red de carreteras de ICPC.
     * @param color Color que identifica a la intersección.
     * @param x Poscición en el eje x de la intersección.
     * @param y Poscición en el eje y de la intersección.
     */
    public void addIntersection(String color, int x, int y){
        if ((x <= sizeW - 50 && y <= sizeL - 50) && Canvas.existColor(color)){
            intersection.put(color, new Intersection(color)); 
            intersection.get(color).moveHorizontal(x);
            intersection.get(color).moveVertical(y);
            draw();
            last = true;
        } else{
            last = false;
            if (isVisible){
                JOptionPane.showMessageDialog(null, "No se pudo realizar la acción");
            }
        }
    }
    
    /**
     * Agrega una nueva ruta a la red de carreteras de ICPC dada dos intersecciones existentes.
     * @param intersectionA Color de la primera intersección a la cuál llega la ruta.
     * @param intersectionB Color de la segunda intersección a la cuál llega la ruta.
     */
    public void addRoute(String intersectionA, String intersectionB){
        String[] colors = {intersectionB, intersectionA};
        if (intersectionA.compareTo(intersectionB) < 0){
            colors[0] = intersectionA;
            colors[1] = intersectionB;
        }
        road.put(colors, new Road(intersection.get(intersectionA).getXPosition(),
                                     intersection.get(intersectionA).getYPosition(),
                                     intersection.get(intersectionB).getXPosition(),
                                     intersection.get(intersectionB).getYPosition()));
        draw();
    }
    
    /**
     * Pone una nueva señal de límite de velocidad a la red de carreteras de ICPC.
     * @param intersectionA Color de la primera intersección que conforma la ruta.
     * @param intersectionB Color de la segunda intersección que conforma la ruta.
     * @param speddimit Velocidad máxima que va a tener la carretera.
     */
    public void putSign(String intersectionA, String intersectionB, int speedLimit){
        erase();
        String[] colors = {intersectionB, intersectionA};
        if (intersectionA.compareTo(intersectionB) < 0){
            colors[0] = intersectionA;
            colors[1] = intersectionB;
        }
        sign.put(colors, new Sign(speedLimit));
        sign.get(colors).moveHorizontal((intersection.get(intersectionA).getXPosition()+intersection.get(intersectionB).getXPosition())/2+5);
        sign.get(colors).moveVertical((intersection.get(intersectionA).getYPosition()+intersection.get(intersectionB).getYPosition())/2+5);
        draw();
    }

    /**
     * Elimina una intersección de la red de carreteras de ICPC.
     * @param color Color con el que se identifica la intersección que se va a eliminar.
     */
    public void delIntersection(String color){
        erase();
        String[] keysI = intersections();
        String in = null;
        for (int i = 0; i < keysI.length && in == null; i++){
            if (keysI[i].equals(color)){
               in = keysI[i];
               intersection.remove(in); 
            }
        }
        String[][] keysR = roads();
        for (int i = 0; i < keysR.length; i++){
            if (keysR[i][0].equals(color) || keysR[i][1].equals(color)){
               road.remove(keysR[i]); 
            }
        }
        String[][] keysS = signs();
        for (int i = 0; i < keysS.length; i++){
            if (keysS[i][0].equals(color) || keysS[i][1].equals(color)){
               sign.remove(keysS[i]); 
            }
        }
        draw();
    }
    
    /**
     * Elimina una carretera de la red de carreteras de ICPC.
     * @param locationA Color de la primera intersección que conforma al ruta.
     * @param locationB Color de la segunda intersección que conforma al ruta.
     */
    public void delRoad(String locationA, String locationB){
        erase();
        String[] r = null;
        String[][] keysR = roads();
        for (int i = 0; i < keysR.length &&  r == null; i++){
            if ((keysR[i][0].equals(locationA) && keysR[i][1].equals(locationB)) || (keysR[i][1].equals(locationA) && keysR[i][0].equals(locationB))){
               r = keysR[i];
               road.get(r).makeInvisible();
               road.remove(r);
            }
        }
        String[] s = null;
        String[][] keysS = signs();
        for (int i = 0; i < keysS.length &&  s == null; i++){
            if ((keysS[i][0].equals(locationA) && keysS[i][1].equals(locationB)) || (keysS[i][1].equals(locationA) && keysS[i][0].equals(locationB))){
               s = keysS[i];
               sign.get(s).makeInvisible();
               sign.remove(s); 
            }
        }
        draw();
    }
    
    /**
     * Quita una señal de límite de velocidad a la red de carreteras de ICPC.
     * @param intersectionA Color de la primera intersección que conforma al ruta donde está ubicada la señal.
     * @param intersectionB Color de la segunda intersección que conforma al ruta donde está ubicada la señal.
     */
    public void removeSign(String intersectionA, String intersectionB){
        erase();
        String[] s = null;
        String[][] keysS = signs();
        for (int i = 0; i < keysS.length &&  s == null; i++){
            if ((keysS[i][0].equals(intersectionA) && keysS[i][1].equals(intersectionB)) || (keysS[i][1].equals(intersectionA) && keysS[i][0].equals(intersectionB))){
               s = keysS[i];
               sign.get(s).makeInvisible();
               sign.remove(s); 
            }
        }
        draw();
    }
    
    /**
     * Da todas las intersecciones que se encuentran el la red de carreteras de ICPC.
     * @return Retorna un arreglo con los colores que se identifican las intersecciones.
     */
    public String[] intersections(){
        return intersection.keySet().toArray(new String[intersection.keySet().size()]);
    }
    
    /**
     * Da todas las carreteras que se encuentran el la red de carreteras de ICPC.
     * @return Retorna un arreglo con los colores de las intersecciones que conforman la rutas.
     */
    public String[][] roads(){
        return road.keySet().toArray(new String[road.keySet().size()][]);
    }
    
    
    /**
     * Da todas las señales de límite de velocidad que se encuentran el la red de carreteras de ICPC.
     * @return Retorna un arreglo con los colores de las intersecciones que conforman la rutas donde se encuentran las señales de límite de velocidad.
     */
    public String[][] signs(){
        return sign.keySet().toArray(new String[sign.keySet().size()][]);
    }
      
    /**
     * Hace visible la red de carreteras de ICPC.
     */
    public void makeVisible(){
        isVisible = true;
        draw();
    }
    
    /**
     * Hace Invisible la red de carreteras de ICPC.
     */
    public void makeInvisible(){
        isVisible = false;
        erase();
    }
    
    /*
     * Dibuja en la pantalla la red de carreteras de ICPC.
     */
    private void draw() {
        if(isVisible) {
            String[] keysI = intersections();
            String[][] keysR = roads();
            String[][] keysS = signs();
            for (int i = 0; i < keysR.length; i++){
                road.get(keysR[i]).makeVisible();
            }
            for (int i = 0; i < keysI.length; i++){
                intersection.get(keysI[i]).makeVisible();
            }
            for (int i = 0; i < keysS.length; i++){
                sign.get(keysS[i]).makeVisible();
            }
        }
    } 
    
    /*
     * Borra de la pantalla la red de carreteras de ICPC.
     */
    private void erase(){
        if(isVisible) {
            String[] keysI = intersections();
            String[][] keysR = roads();
            String[][] keysS = signs();
            for (int i = 0; i < keysI.length; i++){
                intersection.get(keysI[i]).makeInvisible();
            }
            for (int i = 0; i < keysS.length; i++){
                sign.get(keysS[i]).makeInvisible();
            }
            for (int i = 0; i < keysR.length; i++){
                road.get(keysR[i]).makeInvisible();
            }
        }
    } 
    
    /**
     * Termina el simulador de la red de carreteras de ICPC.
     */
    public void finish(){
        System.exit(0);
    }
    
    /**
     * @return Retorna si la última acción se pudo realizar o no.
     */
    public boolean ok(){
        return last;
    }
}