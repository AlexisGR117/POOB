import java.util.*;
/**
 * Señales de límite de velocidad de la red de carreteras de ICPC.
 * 
 * @author Angel Cuervo y Jefer Gonzalez 
 * @version 1.0 (31/08/2022)
 */
public class Sign{
    private String color;
    private ArrayList<Circle> circles = new ArrayList<Circle>();
    private Number number;
    private boolean isVisible;
    private int xPosition;
    private int yPosition;
    /**
     * Constructor para objetos de clase Sign.
     */
    public Sign(int speedLimit){
        xPosition = 0;
        yPosition = 0;
        number = new Number(speedLimit);
        circles.add(new Circle());
        circles.add(new Circle());
        circles.get(0).changeSize(32);
        circles.get(1).changeSize(26);  
        circles.get(0).changeColor("red");
        circles.get(1).changeColor("white");
        circles.get(1).moveVertical(7);
        circles.get(1).moveHorizontal(7);
        circles.get(0).moveHorizontal(4);
        circles.get(0).moveVertical(4);
        number.moveHorizontal(4);
        number.moveVertical(4);
        if (speedLimit > 99){
            circles.get(0).changeSize(42);
            circles.get(1).changeSize(36);
            circles.get(0).moveVertical(1);
            circles.get(1).moveVertical(1);
            number.moveHorizontal(5);
            number.moveVertical(17);
            circles.get(1).moveVertical(-5);
            circles.get(1).moveHorizontal(-5);
            circles.get(0).moveHorizontal(-5);
            circles.get(0).moveVertical(-5);
            number.moveHorizontal(-5);
            number.moveVertical(-5);
        } else if (speedLimit > 9){
            number.moveHorizontal(6);
            number.moveVertical(11);
        } else {
            number.moveHorizontal(12);
            number.moveVertical(11);
        }
    }
    
    /**
     * Mueve horizontalmente la señal de límite de velocidad.
     * @param distance La distancia deseada en pixeles.
     */
    public void moveHorizontal(int distance){
        circles.get(0).moveHorizontal(distance);
        circles.get(1).moveHorizontal(distance);
        number.moveHorizontal(distance);
    }

    /**
     * Mueve verticalmente la señal de límite de velocidad.
     * @param distance La distancia deseada en pixeles.
     */
    public void moveVertical(int distance){
        circles.get(0).moveVertical(distance);
        circles.get(1).moveVertical(distance);
        number.moveVertical(distance);
    }
    
    /**
     * Hace visible la señal de límite de velocidad.
     */
    public void makeVisible(){
        isVisible = true;
        draw();
    }
    
    /*
     * Dibuja en la pantalla la señal de límite de velocidad.
     */
    private void draw() {
        circles.get(0).makeVisible();
        circles.get(1).makeVisible();
        number.makeVisible();
    } 
    
    /**
     * Hace invisible la señal de límite de velocidad.
     */
    public void makeInvisible(){
        erase();
        isVisible = false;
    }
    
    /*
     * Borra de la pantalla la señal de límite de velocidad. 
     */
    private void erase(){
        circles.get(0).makeInvisible();
        circles.get(1).makeInvisible();
        number.makeInvisible();
    } 
}
