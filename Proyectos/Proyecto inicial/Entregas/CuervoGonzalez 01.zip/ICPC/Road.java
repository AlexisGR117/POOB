import java.util.*;
/**
 * Carreteras de la red de carreteras de ICPC.
 * 
 * @author Angel Cuervo y Jefer Gonzalez 
 * @version 1.0 (31/08/2022)
 */
public class Road{
    private ArrayList<Rhomboid> rhomboids = new ArrayList<Rhomboid>();
    private boolean isVisible;
    private int xPositionOne;
    private int yPositionOne;
    private int xPositionTwo;
    private int yPositionTwo;
    /**
     * Constructor para objetos de clase Road.
     */
    public Road(int x1,int y1,int x2,int y2){
        xPositionOne = x1;
        yPositionOne = y1;
        xPositionTwo = x2;
        yPositionTwo = y2;
        rhomboids.add(new Rhomboid());
        rhomboids.add(new Rhomboid());
        int height;
        int distance;
        int side = 20;
        if (x1 > x2){
            distance = x1 - x2;
            rhomboids.get(0).moveHorizontal(x2);
            rhomboids.get(1).moveHorizontal(x2+5);
        } else if (x1 < x2){
            distance = x2 - x1;
            rhomboids.get(0).moveHorizontal(x1);
            rhomboids.get(1).moveHorizontal(x1+5);
        } else {
            distance = 0;
            rhomboids.get(0).moveHorizontal(x1-10);
            rhomboids.get(1).moveHorizontal(x1-5);
        }
        if (y1 > y2){
            height = y1 - y2;
            rhomboids.get(0).moveVertical(y2+5);
            rhomboids.get(1).moveVertical(y2+5);
        } else if (y1 < y2){
            height = y2 - y1;
            rhomboids.get(0).moveVertical(y1+5);
            rhomboids.get(1).moveVertical(y1+5);
        } else {
            height = 20;
            side = distance;
            distance = 0;
            rhomboids.get(0).moveVertical(y1-10);
            rhomboids.get(1).moveVertical(y1-5);
        }
        if ((x1 > x2 && y2 > y1) || (y1 > y2 && x2 > x1)){
            distance = (-1)*distance;
            if (x1 > x2){
                rhomboids.get(0).moveHorizontal(x1-x2-10);
                rhomboids.get(1).moveHorizontal(x1-x2-10);
            } else {
                rhomboids.get(0).moveHorizontal(x2-x1-10);
                rhomboids.get(1).moveHorizontal(x2-x1-10);   
            }
        } else if ((x1 > x2 && y2 < y1) || (y1 < y2 && x2 > x1)){
            rhomboids.get(0).moveHorizontal(-10);
            rhomboids.get(1).moveHorizontal(-10);  
        }
        if (y2 == y1){
            rhomboids.get(0).changeSize(height+10, side+10, distance);
        } else {
            rhomboids.get(0).changeSize(height, side+10, distance);
        }
        rhomboids.get(0).changeColor("black");
        rhomboids.get(1).changeSize(height, side, distance);
    }
    
    /**
     * Mueve horizontalmente la carretera.
     * @param distance La distancia deseada en pixeles.
     */
    public void moveHorizontal(int distance){
        rhomboids.get(0).moveHorizontal(distance);
        rhomboids.get(1).moveHorizontal(distance);
    }

    /**
     * Mueve verticalmente la carretera.
     * @param distance La distancia deseada en pixeles.
     */
    public void moveVertical(int distance){
        rhomboids.get(0).moveVertical(distance);
        rhomboids.get(1).moveVertical(distance);
    }
    
    /**
     * Hace visible la carretera.
     */
    public void makeVisible(){
        isVisible = true;
        draw();
    }
    
    /*
     * Dibuja en la pantalla la carretera.
     */
    private void draw() {
        rhomboids.get(0).makeVisible();
        rhomboids.get(1).makeVisible();
    } 
    
    /**
     * Hace invisible la carretera.
     */
    public void makeInvisible(){
        erase();
        isVisible = false;
    }
    
    /*
     * Borra de la pantalla la carretera.
     */
    private void erase(){
        rhomboids.get(0).makeInvisible();
        rhomboids.get(1).makeInvisible();
    } 
}
