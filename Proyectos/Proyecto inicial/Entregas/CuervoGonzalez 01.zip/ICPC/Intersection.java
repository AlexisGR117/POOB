import java.util.*;
/**
 * Intersecciones de la red de carreteras de ICPC.
 * 
 * @author Angel Cuervo y Jefer Gonzalez 
 * @version 1.0 (31/08/2022)
 */
public class Intersection{
    private String color;
    private ArrayList<Circle> circles = new ArrayList<Circle>();
    private boolean isVisible;
    private int xPosition;
    private int yPosition;
    /**
     * Contructor para objetos de clase Intersection.
     * @param color Color con el que se identifica la intersección.
     */
    public Intersection(String color){
        xPosition = 0;
        yPosition = 0;
        circles.add(new Circle());
        circles.add(new Circle());
        circles.get(0).changeColor("black");
        circles.get(0).changeSize(50);
        circles.get(1).moveHorizontal(+5);
        circles.get(1).moveVertical(+5);
        circles.get(1).changeColor(color);
    }
    
    /**
     * Mueve horizontalmente la intersección.
     * @param distance La distancia deseada en pixeles.
     */
    public void moveHorizontal(int distance){
        circles.get(0).moveHorizontal(distance);
        circles.get(1).moveHorizontal(distance);
        xPosition += distance;
    }    
    
    /**
     * Mueve verticalmente la intersección.
     * @param distance La distancia deseada en pixeles.
     */
    public void moveVertical(int distance){
        circles.get(0).moveVertical(distance);
        circles.get(1).moveVertical(distance);
        yPosition += distance;
    }
    
    /**
     * Da la posición horizontal en la que se encuentra a intersección.
     * @return Retorna la posición de la intersección en el eje x.
     */
    public int getXPosition(){
        return xPosition;
    }
    
    /**
     * Da la posición vertical en la que se encuentra a intersección.
     * @return Retorna la posición de la intersección en el eje y.
     */
    public int getYPosition(){
        return yPosition;
    }
    
    /**
     * Hace visible la intersección.
     */
    public void makeVisible(){
        isVisible = true;
        draw();
    }
    
    /*
     * Dibuja en la pantalla la interseccion.
     */
    private void draw() {
        circles.get(0).makeVisible();
        circles.get(1).makeVisible();
    } 
    
    /**
     * Hace invisible la intersección.
     */
    public void makeInvisible(){
        erase();
        isVisible = false;
    }
    
    /*
     * Borra de la pantalla la interseccion.
     */
    private void erase(){
        circles.get(0).makeInvisible();
        circles.get(1).makeInvisible();
    } 
}
