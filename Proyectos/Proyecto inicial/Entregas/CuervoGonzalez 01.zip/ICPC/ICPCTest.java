

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class ICPCTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ICPCTest
{
    /**
     * Default constructor for test class ICPCTest
     */
    public ICPCTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @Test
    public void tearDown()
    {
    ICPC mapa = new ICPC(1000, 1000);
    mapa.makeVisible();
    mapa.addIntersection("magenta", 100, 100);
    mapa.addIntersection("red", 275, 200);
    mapa.addIntersection("green", 450, 100);
    mapa.addIntersection("yellow", 100, 450);
    mapa.addRoute("magenta", "red");
    mapa.addRoute("magenta", "yellow");
    mapa.addRoute("magenta", "green");
    mapa.addRoute("yellow", "red");
    mapa.addRoute("green", "red");
    mapa.addRoute("green", "yellow");
    mapa.putSign("yellow", "magenta", 999);
    mapa.putSign("red", "magenta", 999);
    mapa.putSign("yellow", "green", 69);
    mapa.putSign("magenta", "green", 69);
    mapa.putSign("red", "yellow", 8);
    mapa.delIntersection("magenta");
    mapa.delRoad("red", "yellow");
    mapa.removeSign("green", "yellow");
    mapa.makeInvisible();
    }
}
