package icpc;
/**
 * Tipo de ruta que no deja que le pongan señales.
 * 
 * @author Angel Cuervo y Jefer Gonzalez
 * @version 1.0 (17/10/2022)
 */
public class Rebel extends Road{
    /**
     * Constructor para rutas de tipo Rebel.
     * @param x1 Posición en x de la primera intersección.
     * @param y1 Posición en y de la primera intersección.
     * @param x2 Posición en x de la segunda intersección.
     * @param y2 Posición en y de la segunda intersección. 
     */
    public Rebel(int x1,int y1,int x2,int y2){
        super(x1, y1, x2, y2);
        changeBackColor("orange");
    }
}