package icpc;
/**
 * Tipo de ruta que no permiten que las quiten.
 * 
 * @author Angel Cuervo y Jefer Gonzalez
 * @version 1.0 (17/10/2022)
 */
public class Fixed extends Road{
    /**
     * Constructor para rutas de tipo Fixed.
     * @param x1 Posición en x de la primera intersección.
     * @param y1 Posición en y de la primera intersección.
     * @param x2 Posición en x de la segunda intersección.
     * @param y2 Posición en y de la segunda intersección. 
     */
    public Fixed(int x1,int y1,int x2,int y2){
        super(x1, y1, x2, y2);
        changeBackColor("red");
    }
}
